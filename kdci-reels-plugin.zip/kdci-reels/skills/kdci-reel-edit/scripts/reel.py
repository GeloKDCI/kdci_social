#!/usr/bin/env python3
"""KDCI reel pipeline CLI (used by the kdci-reel-edit skill).

  python3 reel.py setup
  python3 reel.py ingest  <asset-folder>            -> creates a job, prints assets + thumbnail paths
  python3 reel.py transcribe --job ID              -> prints the indexed transcript
  python3 reel.py guide                            -> prints the plan guide (house style + plan format)
  python3 reel.py preview --job ID --plan plan.json -> cut, base video, graphics; prints snapshot sheets to review
  python3 reel.py render  --job ID --out DIR        -> starts the final render in the background
  python3 reel.py status  --job ID                  -> progress / result
"""
import argparse, glob, json, os, subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("KDCI_MODELS", str(Path.home() / ".cache" / "kdci-reels" / "models"))

from pipeline.common import Job, DATA, MODELS, STAGES, load_config, save_config, which  # noqa: E402

PARAKEET = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2"
RVM = "https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx"
PIP = ["sherpa-onnx", "soundfile", "onnxruntime", "scipy", "pillow", "numpy"]


def sh(cmd, **kw):
    print("$", " ".join(cmd) if isinstance(cmd, list) else cmd, flush=True)
    return subprocess.run(cmd, check=True, **kw)


BROWSER_FILE = Path.home() / ".cache" / "kdci-reels" / "browser_path"
BROWSER_CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/chromium", "/usr/bin/chromium-browser",
    "C:/Program Files/Google/Chrome/Application/chrome.exe", "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
]


def find_local_browser():
    for c in BROWSER_CANDIDATES:
        if Path(c).exists():
            return c
    pats = ["~/.cache/ms-playwright/chromium*/chrome-*/chrome", "~/.cache/ms-playwright/chromium_headless_shell-*/chrome-*/headless_shell",
            "~/Library/Caches/ms-playwright/chromium*/chrome-mac*/Chromium.app/Contents/MacOS/Chromium",
            "/opt/pw-browsers/chromium-*/chrome-linux/chrome"]
    for p in pats:
        hits = sorted(glob.glob(os.path.expanduser(p)))
        if hits:
            return hits[-1]
    return None


def cmd_setup(a):
    for t in ("ffmpeg", "ffprobe", "npx"):
        which(t)
    try:
        import sherpa_onnx, soundfile, onnxruntime, scipy, PIL  # noqa
    except ImportError:
        flags = ["--break-system-packages"] if not os.environ.get("VIRTUAL_ENV") else []
        sh([sys.executable, "-m", "pip", "install", "-q"] + flags + PIP)
    MODELS.mkdir(parents=True, exist_ok=True)
    if not (MODELS / "sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8" / "tokens.txt").exists():
        sh(f'curl -sL --fail "{PARAKEET}" | tar xj -C "{MODELS}"', shell=True)
    if not (MODELS / "rvm_mobilenetv3_fp32.onnx").exists():
        sh(["curl", "-sL", "--fail", "-o", str(MODELS / "rvm_mobilenetv3_fp32.onnx"), RVM])
    from pipeline.hfrender import hf_cmd
    sh(hf_cmd() + ["--version"], stdout=subprocess.DEVNULL)
    # Browser for the graphics render: use a preinstalled headless Chromium when there is one
    # (Claude cloud sessions), otherwise let HyperFrames find or download its own Chrome.
    pre = sorted(glob.glob("/opt/pw-browsers/chromium_headless_shell-*/chrome-linux/headless_shell"))
    if os.environ.get("HYPERFRAMES_BROWSER_PATH") or pre:
        print("render browser:", os.environ.get("HYPERFRAMES_BROWSER_PATH") or pre[-1])
    else:
        print("No preinstalled Chromium found - installing the HyperFrames render browser (one time, ~150 MB)...")
        r = subprocess.run(hf_cmd() + ["browser", "ensure"], capture_output=True, text=True)
        if r.returncode == 0:
            print("render browser: installed by HyperFrames")
        else:
            found = find_local_browser()
            if found:
                BROWSER_FILE.parent.mkdir(parents=True, exist_ok=True)
                BROWSER_FILE.write_text(found)
                print("HyperFrames could not download its browser; using the installed browser:", found)
            else:
                print("WARNING: no render browser. HyperFrames could not download Chrome "
                      "(network blocked?) and no Chrome/Chromium is installed. Install Google Chrome, "
                      "or set HYPERFRAMES_BROWSER_PATH, then run setup again.\n" + (r.stdout + r.stderr)[-600:])
                sys.exit(1)
    print("setup ok. models:", MODELS)


def cmd_ingest(a):
    from pipeline import assets as A
    files = [(p, p.name, c) for p, rel, c in A.scan_folder(a.folder)]
    skip = [s.lower() for s in (a.skip or [])]
    files = [f for f in files if not any(s in str(f[0]).lower() for s in skip)]
    over = dict(x.split("=", 1) for x in (a.set or []))
    files = [(p, n, over.get(n, c)) for p, n, c in files]
    j = Job.create(a.title or "New reel")
    A.ingest(j, files)
    errs = A.validate(j)
    j.stage("intake", "error" if errs else "done", 1, "; ".join(errs) or f"{len(files)} assets")
    print(f"JOB {j.id}   (folder {j.dir})")
    for aid, it in j.state["assets"].items():
        extra = (f"{it.get('duration', 0):.1f}s" + (f" {it['width']}x{it['height']}" if it.get('width') else '')) if it.get("duration") else (it.get("kind") or "")
        th = f"  thumb: {j.dir / it['thumb']}" if it.get("thumb") else ""
        print(f"- [{it['cat']}] {aid}  ({it['name']}) {extra}{th}")
    if errs:
        print("PROBLEMS:", *errs, sep="\n  ")
        sys.exit(1)


def cmd_transcribe(a):
    from pipeline import assets as A, transcribe, plan as P
    j = Job(a.job)
    raw = A.one(j, "raw", required=True)
    j.stage("transcribe", "running", 0.1, "")
    words = transcribe.transcribe_raw(j, raw["path"])
    j.state["transcript"] = " ".join(w["w"] for w in words)
    j.stage("transcribe", "done", 1, f"{len(words)} words")
    print(f"{len(words)} words, raw length {raw.get('duration', 0):.1f}s\n")
    print(P.transcript_text(words))


def cmd_guide(a):
    from pipeline import plan as P
    print((HERE / "pipeline" / "plan_guide.md").read_text().replace("{{URL}}", a.url))
    print("\n## Plan JSON schema\n```json\n" + json.dumps(P.SCHEMA, indent=1) + "\n```")
    print(f"\nHouse-style example plan (another reel, different word indices): {HERE / 'pipeline' / 'plan_example.json'}")


def snapshot(j, times):
    from pipeline.hfrender import hf_cmd
    env = dict(os.environ)
    hs = sorted(glob.glob("/opt/pw-browsers/chromium_headless_shell-*/chrome-linux/headless_shell"))
    if hs and not env.get("HYPERFRAMES_BROWSER_PATH"):
        env["HYPERFRAMES_BROWSER_PATH"] = hs[-1]
    if not env.get("HYPERFRAMES_BROWSER_PATH") and BROWSER_FILE.exists():
        env["HYPERFRAMES_BROWSER_PATH"] = BROWSER_FILE.read_text().strip()
    art = j.hf / ".hyperframes" / "artifacts" / "snapshots"
    before = set(art.glob("*")) if art.exists() else set()
    subprocess.run(hf_cmd() + ["snapshot", "--at", ",".join(f"{t:.2f}" for t in times), "--no-end"],
                   cwd=str(j.hf), env=env, capture_output=True, text=True, timeout=900)
    new = [d for d in art.glob("*") if d not in before] if art.exists() else []
    if not new:
        return []
    frames = sorted(max(new, key=lambda d: d.stat().st_mtime).glob("frame-*.png"))
    from PIL import Image, ImageDraw
    sheets = []
    per = 8
    for k in range(0, len(frames), per):
        chunk = frames[k:k + per]
        c = Image.new("RGB", (len(chunk) * 360, 660), (0, 0, 0))
        for i, f in enumerate(chunk):
            c.paste(Image.open(f).convert("RGB").resize((360, 640)), (i * 360, 20))
            ImageDraw.Draw(c).text((i * 360 + 6, 3), f"{times[k + i]:.1f}s", fill=(255, 220, 0))
        out = j.dir / f"preview_sheet_{k // per + 1}.jpg"
        c.save(out, quality=85)
        sheets.append(out)
    for d in new:
        subprocess.run(["rm", "-rf", str(d)])
    return sheets


def cmd_preview(a):
    from pipeline import runner, plan as P
    j = Job(a.job)
    words = json.load(open(j.p("words_raw.json")))
    pl = json.load(open(a.plan))
    pl = P.normalize(pl, words, j.state["assets"])
    j.state["plan"] = pl
    j.state["title"] = pl.get("title") or j.state["title"]
    j.stage("plan", "done", 1, j.state["title"])
    j.save()
    runner.build_preview(j)
    st = Job(a.job).state
    print(f"Edit length {st['main']:.1f}s  (raw {next(x for x in st['assets'].values() if x['cat'] == 'raw').get('duration', 0):.1f}s)")
    print("Shots:", len(st["edl"]["aroll"]), "A-roll,", len(st["edl"]["broll"]), "B-roll")
    for b in st["edl"]["broll"]:
        print(f"  broll {b['T0']:6.2f}-{b['T1']:6.2f}  {b['asset']}")
    times = []
    for gid, (s, e) in sorted(st["spans"].items(), key=lambda x: x[1][0]):
        print(f"  {gid}: {s:6.2f}-{e:6.2f}")
        times.append(max(s + 0.2, e - 0.5))      # near the end = all elements popped in
    times.append(min(1.0, st["main"] / 3))
    if not a.no_snapshots:
        sheets = snapshot(j, sorted(times))
        print("Review these snapshot sheets (look for text under the head, overflow, contrast):")
        for s in sheets:
            print("  ", s)
    print(f"Preview composition: {j.hf / 'index.html'}   audio: {j.p('preview_audio.m4a')}")
    print(f"Voice before/after: {j.p('voice_before_after.mp3')}")


def cmd_render(a):
    j = Job(a.job)
    cfg = load_config()
    cfg["output_dir"] = str(Path(a.out).expanduser())
    cfg["workers"] = int(a.workers or max(1, os.cpu_count() or 2))
    save_config(cfg)
    for k in ("review",):
        j.stage(k, "done", 1, "approved")
    log = open(j.dir / "render_bg.log", "w")
    subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "_finalize", "--job", a.job], stdout=log, stderr=subprocess.STDOUT,
                     stdin=subprocess.DEVNULL, start_new_session=True, env=dict(os.environ))
    print(f"Render started in the background for job {a.job}. Poll with:  python3 {Path(__file__).resolve()} status --job {a.job}")


def cmd_finalize(a):
    from pipeline import runner
    runner.finalize(Job(a.job))


def cmd_status(a):
    j = Job(a.job)
    s = j.state
    for k, lbl in STAGES:
        x = s["stages"][k]
        print(f"{lbl:22s} {x['status']:8s} {int(x['progress'] * 100):3d}%  {x['msg']}")
    if s.get("error"):
        print("ERROR:", s["error"])
    if s.get("output"):
        print("OUTPUT:", json.dumps(s["output"]))
    print("busy" if s.get("busy") else "idle", "| last log:", *(s["log"][-3:]), sep="\n  ")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("setup")
    p = sp.add_parser("ingest"); p.add_argument("folder"); p.add_argument("--title")
    p.add_argument("--skip", nargs="*", help="substrings of paths to leave out")
    p.add_argument("--set", nargs="*", help="override a category: '<file name>=<cat>'")
    p = sp.add_parser("transcribe"); p.add_argument("--job", required=True)
    p = sp.add_parser("guide"); p.add_argument("--url", default="kdci.co")
    p = sp.add_parser("preview"); p.add_argument("--job", required=True); p.add_argument("--plan", required=True)
    p.add_argument("--no-snapshots", action="store_true")
    p = sp.add_parser("render"); p.add_argument("--job", required=True); p.add_argument("--out", required=True); p.add_argument("--workers")
    p = sp.add_parser("_finalize"); p.add_argument("--job", required=True)
    p = sp.add_parser("status"); p.add_argument("--job", required=True)
    a = ap.parse_args()
    {"setup": cmd_setup, "ingest": cmd_ingest, "transcribe": cmd_transcribe, "guide": cmd_guide, "preview": cmd_preview,
     "render": cmd_render, "_finalize": cmd_finalize, "status": cmd_status}[a.cmd](a)


if __name__ == "__main__":
    main()

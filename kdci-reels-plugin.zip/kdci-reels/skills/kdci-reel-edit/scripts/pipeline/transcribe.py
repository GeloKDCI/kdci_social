"""Word-level transcription with NVIDIA Parakeet TDT 0.6B (sherpa-onnx, runs offline on CPU)."""
import json
import numpy as np
import soundfile as sf
from .common import MODELS, run, which

MODEL_DIR = MODELS / "sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8"
_rec = None


def recognizer():
    global _rec
    if _rec is None:
        import sherpa_onnx, os
        d = MODEL_DIR
        if not (d / "tokens.txt").exists():
            raise RuntimeError("Transcription model missing - run setup.command.")
        _rec = sherpa_onnx.OfflineRecognizer.from_transducer(
            encoder=str(d / "encoder.int8.onnx"), decoder=str(d / "decoder.int8.onnx"),
            joiner=str(d / "joiner.int8.onnx"), tokens=str(d / "tokens.txt"),
            model_type="nemo_transducer", num_threads=max(1, min(8, (os.cpu_count() or 2))))
    return _rec


def asr(wav16):
    a, sr = sf.read(wav16, dtype="float32")
    if a.ndim > 1:
        a = a.mean(1)
    r = recognizer()
    words = []
    # chunk long audio (~60s pieces cut at quiet points) to keep memory low
    hop = sr * 55
    pos = 0
    while pos < len(a):
        end = min(len(a), pos + hop)
        if end < len(a):
            win = a[end - sr * 3:end + sr * 3]
            e = np.convolve(win ** 2, np.ones(1600) / 1600, mode="same")
            end = end - sr * 3 + int(np.argmin(e))
        s = r.create_stream()
        s.accept_waveform(sr, a[pos:end])
        r.decode_stream(s)
        cur = None
        for t, ts in zip(s.result.tokens, s.result.timestamps):
            if t.startswith((" ", "▁")) or cur is None:
                if cur and cur["w"]:
                    words.append(cur)
                cur = {"w": t.strip(" ▁"), "s": round(ts + pos / sr, 2)}
            else:
                cur["w"] += t
        if cur and cur["w"]:
            words.append(cur)
        pos = end
    return words


def transcribe_raw(job, raw_path):
    w16 = job.p("raw16.wav")
    run([which("ffmpeg"), "-v", "error", "-y", "-i", raw_path, "-vn", "-ac", "1", "-ar", "16000", w16])
    run([which("ffmpeg"), "-v", "error", "-y", "-i", raw_path, "-vn", "-ac", "1", "-ar", "48000", "-c:a", "pcm_f32le", job.p("raw48.wav")])
    words = asr(w16)
    # envelope (10 ms RMS, dB) used later for cutting
    a, sr = sf.read(w16, dtype="float32")
    hop = sr // 100
    n = len(a) // hop
    env = np.sqrt((a[: n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)
    np.save(job.p("env.npy"), 20 * np.log10(env))
    json.dump(words, open(job.p("words_raw.json"), "w"))
    return words

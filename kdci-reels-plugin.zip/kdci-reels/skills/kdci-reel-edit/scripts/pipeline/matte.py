"""Person cut-out with Robust Video Matting (ONNX) on the A-roll windows that carry
behind-the-head panels, plus head-top measurement per graphic."""
import subprocess, time
import numpy as np
from .common import MODELS, FPS, which

RVM = MODELS / "rvm_mobilenetv3_fp32.onnx"


def matte(job, main, windows, cuts, out_path):
    """windows: [(T0,T1)] cut-timeline ranges to matte. cuts: frame numbers where the recurrent state resets."""
    import onnxruntime as ort
    if not RVM.exists():
        raise RuntimeError("Matting model missing - run setup.command.")
    so = ort.SessionOptions()
    sess = ort.InferenceSession(str(RVM), so, providers=["CPUExecutionProvider"])
    NF = round(main * FPS)
    win_frames = [(round(a * FPS), round(b * FPS)) for a, b in windows]
    inw = np.zeros(NF + 1, bool)
    for a, b in win_frames:
        inw[a:b] = True
    total = int(inw.sum()) or 1
    cutset = set(cuts)
    dec = subprocess.Popen([which("ffmpeg"), "-v", "error", "-i", job.p("base.mp4"), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                           stdout=subprocess.PIPE)
    enc = subprocess.Popen([which("ffmpeg"), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", "1080x1920",
                            "-r", str(FPS), "-i", "-", "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le",
                            out_path], stdin=subprocess.PIPE)
    blank = np.zeros((1920, 1080, 4), np.uint8).tobytes()
    rec = None
    dr = np.array([0.25], np.float32)
    heads = {}
    done = 0
    t0 = time.time()
    try:
        for f in range(NF):
            buf = dec.stdout.read(1080 * 1920 * 3)
            if len(buf) < 1080 * 1920 * 3:
                enc.stdin.write(blank); continue
            if not inw[f]:
                enc.stdin.write(blank); rec = None; continue
            if rec is None or f in cutset:
                rec = [np.zeros((1, 1, 1, 1), np.float32)] * 4
            img = np.frombuffer(buf, np.uint8).reshape(1920, 1080, 3)
            src = (img.astype(np.float32) / 255).transpose(2, 0, 1)[None]
            fgr, pha, *rec = sess.run(None, {"src": src, "r1i": rec[0], "r2i": rec[1], "r3i": rec[2], "r4i": rec[3],
                                             "downsample_ratio": dr})
            a = np.clip((pha[0, 0] - 0.08) / 0.84, 0, 1)
            fg = (fgr[0].transpose(1, 2, 0) * 255).clip(0, 255).astype(np.uint8)
            rgb = np.where((a > 0.97)[..., None], img, fg)
            enc.stdin.write(np.dstack([rgb, (a * 255).astype(np.uint8)]).tobytes())
            # head top: first row (on a 4x-downsampled grid) with >3 px of solid alpha
            small = a[::4, ::4] > 0.5
            rows = np.where(small.sum(1) > 3)[0]
            if len(rows):
                heads[f] = int(rows[0] * 4)
            done += 1
            if done % 15 == 0:
                el = time.time() - t0
                job.stage("matte", progress=done / total, msg=f"{done}/{total} frames, ~{int(el / done * (total - done))}s left")
                job.check_cancel()
    finally:
        try: enc.stdin.close()
        except Exception: pass
        enc.wait(); dec.kill()
    return heads


def heads_for(windows_by_gid, heads, default=380):
    out = {}
    for gid, (a, b) in windows_by_gid.items():
        vals = [heads[f] for f in range(round(a * FPS), round(b * FPS)) if f in heads]
        out[gid] = int(min(vals)) if vals else default
    return out

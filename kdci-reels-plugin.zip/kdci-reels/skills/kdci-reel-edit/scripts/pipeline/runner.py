"""Job orchestration: prepare (transcribe → plan → preview build) and final render."""
import hashlib, json, re, shutil, traceback
from pathlib import Path
import numpy as np
from .common import Job, Cancelled, FPS, load_config, run, which, video_info
from . import assets as A, transcribe, plan as P, cut, audio, base, compose, matte, hfrender


def _h(x):
    return hashlib.md5(json.dumps(x, sort_keys=True).encode()).hexdigest()[:12]


def guarded(stage_key_fn):
    def deco(fn):
        def wrap(job, *a, **k):
            job.state["busy"] = True; job.state["error"] = None; job.save()
            try:
                return fn(job, *a, **k)
            except Cancelled:
                job.log("Cancelled.")
                for s in job.state["stages"].values():
                    if s["status"] == "running": s["status"] = "pending"
                job.state["status"] = "cancelled"
            except Exception as e:
                tb = traceback.format_exc()
                print(tb, flush=True)
                for s in job.state["stages"].values():
                    if s["status"] == "running": s["status"] = "error"
                job.state["error"] = str(e)[:2000]
                job.state["status"] = "error"
                job.log(f"ERROR: {e}")
            finally:
                cf = job.dir / "CANCEL"
                if cf.exists(): cf.unlink()
                job.state["busy"] = False; job.save()
        return wrap
    return deco


def ctx(job):
    words = json.load(open(job.p("words_raw.json")))
    plan = job.state["plan"]
    keeps = json.load(open(job.p("keeps.json")))
    tl = cut.Timeline(keeps)
    wT = tl.words_T(words, plan["keep"])
    return words, plan, tl, wT


@guarded(None)
def prepare(job, replan_notes=None):
    cfg = load_config()
    st = job.state
    raw = A.one(job, "raw", required=True)
    if st["stages"]["transcribe"]["status"] != "done" or not Path(job.p("words_raw.json")).exists():
        job.stage("transcribe", "running", 0.1, "extracting audio")
        job.log("Transcribing the raw clip…")
        words = transcribe.transcribe_raw(job, raw["path"])
        st["transcript"] = " ".join(w["w"] for w in words)
        job.stage("transcribe", "done", 1, f"{len(words)} words")
    words = json.load(open(job.p("words_raw.json")))
    if not words:
        raise RuntimeError("No speech found in the raw clip.")
    if st.get("plan") is None or replan_notes is not None:
        job.stage("plan", "running", 0.2, "asking Claude" if cfg.get("api_key") else "rule-based draft")
        if cfg.get("api_key"):
            pl = P.claude_plan(job, words, cfg, notes=replan_notes or "", previous=st.get("plan") if replan_notes else None)
        else:
            job.log("No Claude API key set - using the rule-based draft plan (add a key in Settings for a tailored edit).")
            pl = P.heuristic_plan(job, words, cfg.get("brand_url") or "kdci.co")
        pl = P.normalize(pl, words, st["assets"])
        st["plan"] = pl
        st["title"] = pl["title"]
        job.save()
        job.stage("plan", "done", 1, pl["title"])
        job.log(f"Plan: {len(pl['shots'])} shots, {len(pl['graphics'])} graphics. {pl.get('summary', '')}")
    build_preview(job, cfg)


def build_preview(job, cfg=None):
    cfg = cfg or load_config()
    st = job.state
    words = json.load(open(job.p("words_raw.json")))
    pl = P.normalize(st["plan"], words, st["assets"])
    st["plan"] = pl
    raw = A.one(job, "raw", required=True)
    hk, hs = _h(pl["keep"]), _h([pl["keep"], pl["shots"]])
    if st.get("_keep_hash") != hk or not Path(job.p("vo.wav")).exists():
        job.stage("audio", "running", 0.2, "cutting dead air")
        db = np.load(job.p("env.npy"))
        if not Path(job.p("raw48.wav")).exists():
            run([which("ffmpeg"), "-v", "error", "-y", "-i", raw["path"], "-vn", "-ac", "1", "-ar", "48000", "-c:a", "pcm_f32le", job.p("raw48.wav")])
        keeps = cut.compute_keeps(words, pl["keep"], db)
        cut.save(job, keeps)
        audio.enhance(job, keeps)
        tl = cut.Timeline(keeps)
        mus = A.one(job, "music")
        audio.preview_mix(job, mus["path"] if mus else None, tl.main)
        raw_d = raw.get("duration", 0)
        job.log(f"Cut {raw_d:.1f}s raw → {tl.main:.1f}s ({len(keeps)} pieces)")
        st["_keep_hash"] = hk; st["_shots_hash"] = None; st["main"] = tl.main
        job.stage("audio", "done", 1, f"{tl.main:.1f}s")
    words, pl, tl, wT = ctx(job)
    AR, BR = base.build_edl(pl, tl, wT, st["assets"])
    if st.get("_shots_hash") != hs or not Path(job.p("base.mp4")).exists():
        job.stage("base", "running", 0.0, "rendering shots")
        job.log(f"Rendering base video: {len(AR)} A-roll + {len(BR)} B-roll shots")
        base.render_base(job, tl, AR, BR, raw["path"], workers=cfg.get("workers", 2))
        st["_shots_hash"] = hs
        job.stage("base", "done", 1, f"{len(AR) + len(BR)} shots")
    job.stage("compose", "running", 0.5, "graphics + captions")
    heads = st.get("heads") if st.get("_heads_hash") == hs else {}
    info = compose.build(job, pl, wT, tl.main, heads or {}, tl.bounds, AR, with_person=False, kw_idx=pl.get("keywords"))
    st["edl"] = {"aroll": AR, "broll": BR}
    st["spans"] = {g["_id"]: g["_span"] for g in info["graphics"] if "_id" in g}
    st["preview_ready"] = True
    st["preview_rev"] = st.get("preview_rev", 0) + 1
    st["status"] = "review"
    job.stage("compose", "done", 1, f"{len(info['graphics'])} graphics")
    job.stage("review", "running", 0, "preview ready - review and approve")
    job.log("Preview ready.")


@guarded(None)
def rebuild(job):
    build_preview(job)


@guarded(None)
def finalize(job):
    cfg = load_config()
    st = job.state
    st["status"] = "rendering"
    job.stage("review", "done", 1, "approved")
    words, pl, tl, wT = ctx(job)
    AR, BR = base.build_edl(pl, tl, wT, st["assets"])
    if not Path(job.p("base.mp4")).exists() or st.get("_shots_hash") != _h([pl["keep"], pl["shots"]]):
        build_preview(job, cfg)
        words, pl, tl, wT = ctx(job)
        AR, BR = base.build_edl(pl, tl, wT, st["assets"])
    # 1. compose once to learn which windows need the person matte
    info = compose.build(job, pl, wT, tl.main, {}, tl.bounds, AR, with_person=False, kw_idx=pl.get("keywords"))
    mw = info["matte_windows"]
    windows = []
    by_gid = {}
    for gid, (s, e) in mw.items():
        for a in AR:
            lo, hi = max(s, a["T0"]), min(e, a["T1"])
            if hi - lo > 0.05:
                windows.append((lo, hi)); by_gid.setdefault(gid, []).append((lo, hi))
    hs = _h([pl["keep"], pl["shots"]])
    wkey = _h([hs, sorted(windows)])
    if st.get("_matte_hash") != wkey or not Path(job.p("person.mov")).exists():
        job.stage("matte", "running", 0, f"{sum(b - a for a, b in windows):.0f}s of A-roll")
        job.log("Cutting out the talent for behind-the-head panels…")
        cuts_f = sorted({round(a["T0"] * FPS) for a in AR} | {round(b * FPS) for b in tl.bounds})
        heads_f = matte.matte(job, tl.main, windows, cuts_f, job.p("person.mov"))
        heads = {}
        for gid, ws in by_gid.items():
            vals = [heads_f[f] for a, b in ws for f in range(round(a * FPS), round(b * FPS)) if f in heads_f]
            heads[gid] = int(min(vals)) if vals else 380
        st["heads"] = heads; st["_heads_hash"] = hs; st["_matte_hash"] = wkey
        job.log(f"Head tops: {heads}")
    job.stage("matte", "done", 1, "")
    info = compose.build(job, pl, wT, tl.main, st.get("heads") or {}, tl.bounds, AR, with_person=True, kw_idx=pl.get("keywords"))
    # 2. render graphics
    job.stage("render", "running", 0, "starting renderer")
    job.log("Rendering graphics with HyperFrames (the longest step)…")
    hfrender.render(job, job.p("hf.mp4"), workers=cfg.get("workers", 2))
    job.stage("render", "done", 1, "")
    # 3. mix + composite
    job.stage("final", "running", 0.2, "mixing audio")
    mus = A.one(job, "music"); ec = A.one(job, "endcard")
    pop = A.one(job, "sfx_pop"); ty = A.one(job, "sfx_typing")
    typing_at = [b["T0"] + 0.1 for b in BR if b.get("sfx") == "typing"]
    ec_len = min(5.0, ec.get("duration", 5)) if ec else 0.0
    TOT = audio.final_mix(job, tl.main, mus["path"] if mus else None, ec, pop["path"] if pop else None,
                          ty["path"] if ty else None, sorted(info["pops"]), typing_at, endcard_len=ec_len or 5.0)
    job.stage("final", "running", 0.6, "encoding")
    M = tl.main
    out_tmp = job.p("final.mp4")
    if ec:
        fc = (f"[0:v]fps=30,trim=0:{M},setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration={ec_len}[b];"
              f"[1:v]trim=0:{ec_len},setpts=PTS-STARTPTS+{M}/TB,scale=1080:1920,format=yuva444p[e];"
              f"[b][e]overlay=eof_action=pass:format=auto,trim=0:{M + ec_len},format=yuv420p[v]")
        inp = ["-i", job.p("hf.mp4"), "-i", ec["path"], "-i", job.p("mix.wav")]
        amap = "2:a"
    else:
        fc = f"[0:v]fps=30,trim=0:{M},setpts=PTS-STARTPTS,format=yuv420p[v]"
        inp = ["-i", job.p("hf.mp4"), "-i", job.p("mix.wav")]
        amap = "1:a"
    run([which("ffmpeg"), "-v", "error", "-y"] + inp + ["-filter_complex", fc, "-map", "[v]", "-map", amap,
         "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-profile:v", "high", "-c:a", "aac", "-b:a", "320k",
         "-ar", "48000", "-movflags", "+faststart", "-shortest", out_tmp])
    # 4. save to the output folder, never overwriting
    outdir = Path(cfg["output_dir"]).expanduser()
    outdir.mkdir(parents=True, exist_ok=True)
    stem = f"KDCI Reel - {st.get('title') or 'Untitled'}"
    n = 1
    while (outdir / f"{stem}_v{n}.mp4").exists():
        n += 1
    dst = outdir / f"{stem}_v{n}.mp4"
    shutil.copy2(out_tmp, dst)
    r = run([which("ffmpeg"), "-hide_banner", "-i", str(dst), "-af", "ebur128", "-f", "null", "-"], check=False)
    lufs = next((l.split()[1] for l in r.stderr.splitlines()[::-1] if l.strip().startswith("I:")), "?")
    st["output"] = {"path": str(dst), "name": dst.name, "duration": round(video_info(dst)["duration"], 2), "lufs": lufs}
    st["status"] = "done"
    job.stage("final", "done", 1, dst.name)
    job.log(f"Saved {dst}  ({lufs} LUFS)")
    # free the large intermediates (keep base + plan so the job can be re-rendered)
    for f in ("person.mov", "premix.wav", "raw48.wav", "enh48.wav", "cut48.wav", "hf.mp4"):
        try: Path(job.p(f)).unlink()
        except Exception: pass
    st["_matte_hash"] = None
    hp = job.hf / "assets" / "person.mov"
    if hp.exists(): hp.unlink()
    compose.build(job, pl, wT, tl.main, st.get("heads") or {}, tl.bounds, AR, with_person=False, kw_idx=pl.get("keywords"))

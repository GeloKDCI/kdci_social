"""Runs `npx hyperframes render` on the job's composition and reports progress."""
import os, re, shutil, subprocess, time
from .common import ROOT, which

HF_VERSION = "0.8.179"


def hf_cmd():
    local = ROOT / "node_modules" / ".bin" / "hyperframes"
    if local.exists():
        return [str(local)]
    return [which("npx"), "--yes", f"hyperframes@{HF_VERSION}"]


def render(job, out_path, workers=2):
    cache = job.dir / "hf-cache"
    cache.mkdir(exist_ok=True)
    env = dict(os.environ)
    if not env.get("HYPERFRAMES_BROWSER_PATH"):
        import glob
        hs = sorted(glob.glob("/opt/pw-browsers/chromium_headless_shell-*/chrome-linux/headless_shell"))
        if hs: env["HYPERFRAMES_BROWSER_PATH"] = hs[-1]
    env = dict(env, FFMPEG_PROCESS_TIMEOUT_MS="3600000", HYPERFRAMES_EXTRACT_CACHE_DIR=str(cache),
               PRODUCER_PLAYER_READY_TIMEOUT_MS="180000")
    log = open(job.p("render.log"), "w")
    cmd = hf_cmd() + ["render", "-o", out_path, "--no-low-memory-mode", "--workers", str(workers), "-q", "delivery"]
    p = subprocess.Popen(cmd, cwd=str(job.hf), env=env, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.PIPE)
    pat = re.compile(r"(\d+)%\s+(.*)")
    last = ""
    try:
        while p.poll() is None:
            time.sleep(2)
            if (job.dir / "CANCEL").exists():
                p.terminate(); p.wait(10)
                raise RuntimeError("Cancelled")
            try:
                with open(job.p("render.log"), "rb") as f:
                    f.seek(max(0, os.path.getsize(job.p("render.log")) - 4000))
                    tail = f.read().decode("utf8", "ignore")
            except Exception:
                continue
            m = None
            for m in pat.finditer(tail):
                pass
            if m and m.group(0) != last:
                last = m.group(0)
                job.stage("render", progress=int(m.group(1)) / 100, msg=m.group(2).strip()[:80])
    finally:
        log.close()
        shutil.rmtree(cache, ignore_errors=True)
    if p.returncode != 0:
        tail = open(job.p("render.log"), errors="ignore").read()[-1500:]
        raise RuntimeError("HyperFrames render failed:\n" + tail)

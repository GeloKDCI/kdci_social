"""Shared helpers: paths, job state, subprocess wrappers, brand constants."""
import json, os, shutil, subprocess, threading, time
from pathlib import Path

APP = Path(__file__).resolve().parent.parent
ROOT = APP.parent
VENDOR = APP / "vendor"
MODELS = Path(os.environ.get("KDCI_MODELS", Path.home() / ".cache" / "kdci-reels" / "models"))
DATA = Path(os.environ.get("KDCI_STUDIO_DATA", Path.home() / "kdci-reel-jobs"))
JOBS = DATA / "jobs"
CONFIG = DATA / "config.json"

FPS = 30
W, H = 1080, 1920
RED = "#E61739"

STAGES = [
    ("intake", "Assets"),
    ("transcribe", "Transcribe"),
    ("plan", "Edit plan (Claude)"),
    ("audio", "Cut + voice"),
    ("base", "Base video"),
    ("compose", "Graphics + captions"),
    ("review", "Your review"),
    ("matte", "Person cut-out"),
    ("render", "Render graphics"),
    ("final", "Mix + export"),
]

DEFAULT_CONFIG = {
    "api_key": "",
    "model": "",
    "output_dir": str(Path.home() / "Movies" / "KDCI Reels"),
    "workers": max(1, min(4, (os.cpu_count() or 2) // 2)),
    "brand_url": "kdci.co",
}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG.exists():
        try:
            cfg.update(json.loads(CONFIG.read_text()))
        except Exception:
            pass
    if not cfg.get("api_key"):
        cfg["api_key"] = os.environ.get("ANTHROPIC_API_KEY", "")
    return cfg


def save_config(cfg):
    DATA.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=2))
    try:
        os.chmod(CONFIG, 0o600)
    except Exception:
        pass


def which(name):
    p = shutil.which(name)
    if not p:
        raise RuntimeError(f"'{name}' not found. Run setup.command first.")
    return p


class Cancelled(Exception):
    pass


class Job:
    """A reel job living in DATA/jobs/<id>/ with a JSON state file."""
    _locks = {}

    def __init__(self, jid):
        self.id = jid
        self.dir = JOBS / jid
        self.work = self.dir / "work"
        self.assets = self.dir / "assets"
        self.hf = self.dir / "hf"
        self.state_path = self.dir / "state.json"
        self.lock = Job._locks.setdefault(jid, threading.RLock())
        self.state = json.loads(self.state_path.read_text()) if self.state_path.exists() else None

    @classmethod
    def create(cls, title="Untitled reel"):
        jid = time.strftime("%Y%m%d-%H%M%S")
        j = cls(jid)
        for d in (j.dir, j.work, j.assets, j.hf):
            d.mkdir(parents=True, exist_ok=True)
        j.state = {
            "id": jid, "title": title, "created": time.time(), "status": "running",
            "stages": {k: {"status": "pending", "progress": 0, "msg": ""} for k, _ in STAGES},
            "log": [], "assets": {}, "transcript": None, "plan": None, "plan_notes": "",
            "preview_ready": False, "output": None, "error": None, "busy": False, "rev": 0,
        }
        j.save()
        return j

    def save(self):
        with self.lock:
            self.state["rev"] = self.state.get("rev", 0) + 1
            tmp = self.state_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.state, indent=1))
            tmp.replace(self.state_path)

    def log(self, msg):
        with self.lock:
            self.state["log"].append(f"{time.strftime('%H:%M:%S')}  {msg}")
            self.state["log"] = self.state["log"][-400:]
            self.save()
        print(f"[{self.id}] {msg}", flush=True)

    def stage(self, key, status=None, progress=None, msg=None):
        with self.lock:
            s = self.state["stages"][key]
            if status is not None: s["status"] = status
            if progress is not None: s["progress"] = round(float(progress), 3)
            if msg is not None: s["msg"] = msg
            self.save()

    def check_cancel(self):
        if (self.dir / "CANCEL").exists():
            raise Cancelled()

    def p(self, *parts):
        return str(self.work.joinpath(*parts))


def run(cmd, job=None, check=True, **kw):
    """Run a command, raising with the tail of stderr on failure."""
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if check and r.returncode != 0:
        tail = (r.stderr or r.stdout or "")[-1500:]
        raise RuntimeError(f"{os.path.basename(cmd[0])} failed: {tail}")
    return r


def ffprobe_json(path):
    r = run([which("ffprobe"), "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)])
    return json.loads(r.stdout)


def video_info(path):
    j = ffprobe_json(path)
    v = next((s for s in j["streams"] if s.get("codec_type") == "video"), None)
    a = next((s for s in j["streams"] if s.get("codec_type") == "audio"), None)
    dur = float(j["format"].get("duration") or 0)
    info = {"duration": dur, "has_audio": a is not None}
    if v:
        num, den = (v.get("r_frame_rate") or "30/1").split("/")
        w, h = int(v.get("width", 0)), int(v.get("height", 0))
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(sd["rotation"])
        if abs(rot) in (90, 270):
            w, h = h, w
        info.update(width=w, height=h, fps=float(num) / float(den or 1), codec=v.get("codec_name"),
                    pix_fmt=v.get("pix_fmt", ""), alpha=("a" in (v.get("pix_fmt") or "").replace("yuv", "")) or v.get("codec_name") in ("qtrle", "png", "prores"))
    return info

"""Voice enhancement + cutting, music/SFX mix and loudness."""
import json, subprocess
import numpy as np
import soundfile as sf
from scipy.signal import welch
from .common import run, which

BASE_CHAIN = ("highpass=f=80,equalizer=f=320:t=q:w=1.0:g=-3,equalizer=f={f1}:t=q:w=1.1:g={g1},"
              "equalizer=f={f2}:t=q:w=1.0:g={g2},highshelf=f=9000:g={g3},deesser=i=0.4:m=0.5:f=0.5,"
              "acompressor=threshold=-24dB:ratio=3:attack=8:release=150:makeup=5dB:knee=4,alimiter=limit=0.89:level=false")


def spectrum(path):
    a, sr = sf.read(path)
    if a.ndim > 1: a = a.mean(1)
    fr, p = welch(a, sr, nperseg=8192)
    d = 10 * np.log10(p + 1e-20)
    ref = d[(fr > 500) & (fr < 1000)].mean()
    return {k: round(float(d[(fr > lo) & (fr < hi)].mean() - ref), 1)
            for k, (lo, hi) in {"2-4k": (2000, 4000), "4-6k": (4000, 6000), "9-14k": (9000, 14000)}.items()}


def cut_audio(src, dst, keeps, fade=0.013):
    a, sr = sf.read(src, dtype="float32")
    f = int(fade * sr); parts = []
    for s, e in keeps:
        x = a[int(s * sr):int(e * sr)].copy()
        if len(x) > 2 * f:
            r = np.linspace(0, 1, f); x[:f] *= r; x[-f:] *= r[::-1]
        parts.append(x)
    sf.write(dst, np.concatenate(parts), sr, subtype="FLOAT")


def enhance(job, keeps):
    raw = job.p("raw48.wav")
    cut_audio(raw, job.p("cut48.wav"), keeps)
    sp = spectrum(job.p("cut48.wav"))
    db = np.load(job.p("env.npy"))
    floor = float(np.percentile(db, 10))
    # presence: lift more when the source is dull (target ~2-4k -8, 4-6k -15 vs 500-1k)
    g1 = float(np.clip(3 + (-8 - sp["2-4k"]) * 0.45, 2, 7))
    g2 = float(np.clip(2.5 + (-15 - sp["4-6k"]) * 0.45, 2, 8))
    g3 = 3 if sp["9-14k"] < -20 else 1.5
    chain = BASE_CHAIN.format(f1=3000 if g1 < 5 else 2800, g1=round(g1, 1), f2=5300, g2=round(g2, 1), g3=g3)
    if floor > -62:   # audible room noise -> gentle FFT denoise first
        chain = f"afftdn=nr=12:nf={max(-80, int(floor) - 2)}:tn=1," + chain
    job.log(f"Voice: noise floor {floor:.0f} dB, spectrum {sp} -> presence +{g1:.1f}/+{g2:.1f} dB")
    run([which("ffmpeg"), "-v", "error", "-y", "-i", raw, "-af", chain, "-c:a", "pcm_f32le", job.p("enh48.wav")])
    cut_audio(job.p("enh48.wav"), job.p("vo_raw.wav"), keeps)
    # bring VO to about -16 LUFS so the fixed music/end-card levels sit right
    r = run([which("ffmpeg"), "-hide_banner", "-i", job.p("vo_raw.wav"), "-af", "ebur128", "-f", "null", "-"], check=False)
    I = -16.0
    for line in r.stderr.splitlines()[::-1]:
        if line.strip().startswith("I:"):
            I = float(line.split()[1]); break
    gain = float(np.clip(-16 - I, -6, 12))
    run([which("ffmpeg"), "-v", "error", "-y", "-i", job.p("vo_raw.wav"), "-af",
         f"volume={gain:.2f}dB,alimiter=limit=0.89:level=false", "-c:a", "pcm_f32le", job.p("vo.wav")])
    # small preview mp3 (before/after 9s)
    try:
        mid = 8.0
        run([which("ffmpeg"), "-v", "error", "-y", "-i", job.p("cut48.wav"), "-i", job.p("vo.wav"), "-filter_complex",
             f"[0]atrim={mid}:{mid+9},loudnorm=I=-16[a];[1]atrim={mid}:{mid+9},loudnorm=I=-16[b];[a][b]concat=n=2:v=0:a=1",
             "-b:a", "160k", job.p("voice_before_after.mp3")], check=False)
    except Exception:
        pass
    # quick scratch mix for the live preview (voice + quiet music)
    return gain


def preview_mix(job, music_path, main):
    inputs = ["-i", job.p("vo.wav")]
    f = "[0:a]aresample=48000[vo]"
    if music_path:
        inputs += ["-stream_loop", "-1", "-i", music_path]
        f += f";[1:a]aresample=48000,atrim=0:{main},volume=0.07[mu];[vo][mu]amix=inputs=2:normalize=0:duration=first[o]"
    else:
        f += ";[vo]anull[o]"
    run([which("ffmpeg"), "-v", "error", "-y"] + inputs + ["-filter_complex", f, "-map", "[o]", "-b:a", "192k", job.p("preview_audio.m4a")])


def final_mix(job, main, music, endcard, sfx_pop, sfx_typing, pops, typing_at, endcard_len=5.0):
    """Mix VO + music + end card + SFX, two-pass loudnorm to -14 LUFS / -1.5 TP."""
    M = main; TOT = M + (endcard_len if endcard else 0.0)
    inp = ["-i", job.p("vo.wav")]
    f = [f"[0:a]aresample=48000,atrim=0:{M},afade=t=out:st={max(0, M-0.25)}:d=0.25,apad=whole_dur={TOT}[vo]"]
    lab = ["[vo]"]
    k = 1
    if music:
        inp += ["-stream_loop", "-1", "-i", music]
        f.append(f"[{k}:a]aresample=48000,atrim=0:{TOT},volume='if(lt(t,{M}),0.07,0.07+0.18*min((t-{M})/0.6,1))':eval=frame,"
                 f"afade=t=in:d=0.3,afade=t=out:st={max(0,TOT-1.6)}:d=1.6[mu]")
        lab.append("[mu]"); k += 1
    if endcard and endcard.get("has_audio"):
        inp += ["-i", endcard["path"]]
        f.append(f"[{k}:a]aresample=48000,atrim=0:{endcard_len},volume=0.85,afade=t=out:st={endcard_len-0.4}:d=0.4,adelay={int(M*1000)}:all=1[ec]")
        lab.append("[ec]"); k += 1
    if sfx_typing:
        for t in typing_at:
            inp += ["-i", sfx_typing]
            f.append(f"[{k}:a]aresample=48000,atrim=0:1.75,afade=t=out:st=1.4:d=0.35,volume=0.55,adelay={int(t*1000)}:all=1[t{k}]")
            lab.append(f"[t{k}]"); k += 1
    if sfx_pop:
        s0, s1 = pop_window(sfx_pop)
        for t, v in pops:
            inp += ["-i", sfx_pop]
            f.append(f"[{k}:a]aresample=48000,atrim={s0}:{s1},asetpts=PTS-STARTPTS,volume={v},adelay={int(max(0,t)*1000)}:all=1[p{k}]")
            lab.append(f"[p{k}]"); k += 1
    f.append(f"{''.join(lab)}amix=inputs={len(lab)}:normalize=0:duration=first,atrim=0:{TOT}[out]")
    script = job.p("mix_filter.txt")
    open(script, "w").write(";\n".join(f))
    run([which("ffmpeg"), "-v", "error", "-y"] + inp + ["-filter_complex_script", script, "-map", "[out]",
         "-c:a", "pcm_f32le", job.p("premix.wav")])
    r = run([which("ffmpeg"), "-hide_banner", "-i", job.p("premix.wav"), "-af",
             "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"], check=False)
    txt = r.stderr[r.stderr.rfind("{"):r.stderr.rfind("}") + 1]
    try:
        j = json.loads(txt)
        af = (f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={j['input_i']}:measured_TP={j['input_tp']}:"
              f"measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
    except Exception:
        af = "loudnorm=I=-14:TP=-1.5:LRA=11"
    run([which("ffmpeg"), "-v", "error", "-y", "-i", job.p("premix.wav"), "-af", af + ",aresample=48000",
         "-c:a", "pcm_s16le", job.p("mix.wav")])
    return TOT


_popcache = {}


def pop_window(path):
    """Find the first transient in the SFX file (camera shutter packs hold several clicks)."""
    if path in _popcache:
        return _popcache[path]
    tmp = path + ".probe.wav"
    try:
        subprocess.run([which("ffmpeg"), "-v", "error", "-y", "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-t", "20", tmp], check=True)
        a, sr = sf.read(tmp)
        hop = 160
        n = len(a) // hop
        e = 20 * np.log10(np.sqrt((a[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12))
        thr = max(e.max() - 25, -45)
        on = int(np.argmax(e > thr))
        off = on + 1
        while off < n and (e[off] > thr - 10 or off - on < 15) and off - on < 60:
            off += 1
        w = (max(0, on / 100 - 0.02), off / 100 + 0.14)
    except Exception:
        w = (0.0, 0.45)
    _popcache[path] = (round(w[0], 3), round(w[1], 3))
    return _popcache[path]

"""Edit decision list from the plan's shots, and the ffmpeg base-video render
(cuts, punch-in zooms anchored on the face, B-roll with push-in, blur sections)."""
import json, os, subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from .common import FPS, run, which, video_info

LOOKS = {
    "none": "",
    "crimson": ("format=gray,lut=c0='clip((val-160)*2.2,0,255)',format=rgb24,"
                "colorchannelmixer=rr=0.66:rg=0:rb=0:gr=0.06:gg=0:gb=0:br=0.16:bg=0:bb=0,eq=gamma=0.85,vignette=angle=0.7"),
    "brand_red": "hue=h=-128:s=1.15,eq=saturation=1.1",
    "dark": "eq=brightness=-0.08:saturation=0.9,vignette=angle=0.6",
    "mono": "hue=s=0,eq=contrast=1.08",
}


def word_T(wT, idx):
    for w in wT:
        if w["i"] >= idx:
            return w["s"]
    return wT[-1]["s"] if wT else 0.0


def build_edl(plan, tl, wT, assets):
    """Returns (AROLL, BROLL) lists in cut-timeline seconds."""
    shots = sorted(plan.get("shots", []), key=lambda s: s.get("at", 0))
    if not shots or shots[0].get("type") != "aroll":
        shots = [{"at": 0, "type": "aroll", "zoom": 1.0}] + shots
    starts = []
    for k, s in enumerate(shots):
        t = 0.0 if k == 0 else max(0.0, word_T(wT, s["at"]) - 0.06)
        # snap to a nearby keep boundary so cuts land on jump points
        for b in tl.bounds:
            if abs(b - t) < 0.18:
                t = b
        starts.append(round(round(t * FPS) / FPS, 4))
    AROLL, BROLL = [], []
    prev_z = None
    for k, s in enumerate(shots):
        t0 = starts[k]
        t1 = starts[k + 1] if k + 1 < len(shots) else tl.main
        if t1 - t0 < 0.3:
            continue
        if s.get("type") == "broll" and s.get("asset") in assets:
            a = assets[s["asset"]]
            src = float(s.get("src_start", 0) or 0)
            dur = a.get("duration", 0) or 0
            if dur and src + (t1 - t0) > dur:
                src = max(0.0, dur - (t1 - t0) - 0.05)
            fx = float(s.get("fx", 0.5) if s.get("fx") is not None else 0.5)
            BROLL.append(dict(T0=t0, T1=t1, file=a["path"], src=src, fx=min(1, max(0, fx)), z0=1.0, z1=1.08,
                              look=LOOKS.get(s.get("look", "none"), ""), flip=bool(s.get("flip")), loop=dur < (t1 - t0),
                              sfx=s.get("sfx", "none"), asset=s["asset"]))
        else:
            z = float(s.get("zoom", 1.0) or 1.0)
            z = min(1.45, max(1.0, z))
            if prev_z is not None and abs(z - prev_z) < 0.05 and not s.get("blur"):
                z = 1.0 if prev_z > 1.05 else 1.14   # alternate so every cut reads
            prev_z = z
            push = 0.04 if (t1 - t0) > 1.2 else 0.02
            AROLL.append(dict(T0=t0, T1=t1, z0=z, z1=z + push, blur=bool(s.get("blur"))))
    # make sure everything is covered contiguously
    segs = sorted([(x["T0"], x["T1"], "a", x) for x in AROLL] + [(x["T0"], x["T1"], "b", x) for x in BROLL])
    fixed_a, fixed_b, t = [], [], 0.0
    for a0, a1, kind, x in segs:
        x["T0"] = t
        (fixed_a if kind == "a" else fixed_b).append(x)
        t = a1
    if segs:
        segs[-1][3]["T1"] = tl.main
    return fixed_a, fixed_b


def render_base(job, tl, AROLL, BROLL, raw_path, workers=2, anchor=(540, 640)):
    pdir = Path(job.p("pieces")); pdir.mkdir(exist_ok=True)
    for f in pdir.glob("*.mp4"):
        f.unlink()
    AX, AY = anchor
    jobs = []
    enc = ["-c:v", "libx264", "-crf", "14", "-preset", "veryfast", "-g", "30", "-keyint_min", "30", "-pix_fmt", "yuv420p"]
    for x in AROLL:
        T0, T1, z0, z1 = x["T0"], x["T1"], x["z0"], x["z1"]
        k = (z1 - z0) / max(0.01, T1 - T0)
        cuts = [T0] + [b for b in tl.bounds if T0 + 1e-6 < b < T1 - 1e-6] + [T1]
        for a, b in zip(cuts, cuts[1:]):
            N = round(b * FPS) - round(a * FPS)
            if N <= 0: continue
            Z = f"({z0}+{k:.6f}*(t+{a - T0:.4f}))"
            vf = ("scale=1080:1920:force_original_aspect_ratio=increase:flags=bicubic,crop=1080:1920,setsar=1,"
                  f"scale=w='2*trunc(540*{Z})':h=-2:eval=frame:flags=bicubic,"
                  f"crop=1080:1920:x='min(max({AX}*(in_w/1080-1),0),in_w-1080)':y='min(max({AY}*(in_w/1080-1),0),in_h-1920)',"
                  "eq=contrast=1.04:saturation=1.06")
            if x["blur"]:
                vf += ",gblur=sigma=38,eq=brightness=-0.10:saturation=0.85"
            vf += ",setsar=1,format=yuv420p"
            out = pdir / f"{a:09.4f}.mp4"
            jobs.append((a, [which("ffmpeg"), "-v", "error", "-y", "-ss", f"{tl.T2raw(a + 0.0001):.4f}", "-i", raw_path, "-an",
                             "-vf", vf, "-r", str(FPS), "-frames:v", str(N)] + enc + [str(out)], N, out))
    for x in BROLL:
        N = round(x["T1"] * FPS) - round(x["T0"] * FPS)
        k = (x["z1"] - x["z0"]) / max(0.01, x["T1"] - x["T0"])
        Z = f"({x['z0']}+{k:.6f}*t)"
        vf = (f"fps={FPS},scale=w='2*trunc(max(1080/iw\\,1920/ih)*{Z}*iw/2)':h='2*trunc(max(1080/iw\\,1920/ih)*{Z}*ih/2)':eval=frame,"
              f"crop=1080:1920:x='(in_w-1080)*{x['fx']}':y='(in_h-1920)/2',unsharp=5:5:0.6")
        if x["look"]: vf += "," + x["look"]
        if x["flip"]: vf += ",hflip"
        vf += ",setsar=1,format=yuv420p"
        out = pdir / f"{x['T0']:09.4f}.mp4"
        pre = ["-stream_loop", "-1"] if x["loop"] else []
        jobs.append((x["T0"], [which("ffmpeg"), "-v", "error", "-y"] + pre + ["-ss", str(x["src"]), "-i", x["file"], "-an", "-vf", vf,
                                "-r", str(FPS), "-frames:v", str(N)] + enc + [str(out)], N, out))
    jobs.sort(key=lambda j: j[0])
    done = [0]

    def go(j):
        job.check_cancel()
        run(j[1])
        done[0] += 1
        job.stage("base", progress=done[0] / len(jobs) * 0.95, msg=f"piece {done[0]}/{len(jobs)}")

    with ThreadPoolExecutor(max(1, workers)) as ex:
        list(ex.map(go, jobs))
    lst = pdir / "list.txt"
    lst.write_text("".join(f"file '{j[3].name}'\n" for j in jobs))
    run([which("ffmpeg"), "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy",
         "-movflags", "+faststart", job.p("base.mp4")])
    n = int(run([which("ffprobe"), "-v", "error", "-count_packets", "-select_streams", "v", "-show_entries",
                 "stream=nb_read_packets", "-of", "csv=p=0", job.p("base.mp4")]).stdout.strip() or 0)
    exp = round(tl.main * FPS)
    if abs(n - exp) > 2:
        job.log(f"Warning: base has {n} frames, expected {exp}")
    for j in jobs:
        try: j[3].unlink()
        except Exception: pass
    return n

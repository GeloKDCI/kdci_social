"""Asset intake: classify files (from an uploaded set or a folder in the KDCI layout),
copy them into the job, probe them and make thumbnails / contact sheets."""
import re, shutil
from pathlib import Path
from PIL import Image
from .common import run, which, video_info

VIDEO = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi"}
AUDIO = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".aif", ".aiff"}
IMAGE = {".png", ".jpg", ".jpeg", ".webp"}
FONT = {".ttf", ".otf"}
CATS = ["raw", "broll", "images", "music", "endcard", "sfx_pop", "sfx_typing", "font"]
SKIP_DIRS = {"from claude", "exported final video", "exported", "output", "outputs"}


def slug(name):
    s = re.sub(r"[^A-Za-z0-9]+", "_", Path(name).stem).strip("_")[:40] or "file"
    return s + Path(name).suffix.lower()


def guess_category(path: Path, rel: str):
    """Guess an asset category from folder names, file name and type."""
    ext = path.suffix.lower()
    low = rel.lower()
    name = path.name.lower()
    if ext in FONT:
        return "font"
    sfxish = re.search(r"sound ?fx|sfx|sound effect|shutter|camera click|whoosh|pop\b", low)
    if ext in AUDIO or (ext in VIDEO and sfxish):
        if re.search(r"typing|keyboard|laptop|keys", name):
            return "sfx_typing"
        if sfxish:
            return "sfx_pop"
        return "music"
    if ext in IMAGE:
        return "images"
    if ext in VIDEO:
        if "end card" in low or "endcard" in low or "outro" in name or "_alpha" in name:
            return "endcard"
        if "raw" in low or "main footage" in low or "a-roll" in low or "aroll" in low:
            return "raw"
        if "b-roll" in low or "broll" in low or "b roll" in low:
            return "broll"
        return None  # decided after probing
    return None


def scan_folder(folder):
    """Return [(path, rel, category)] for a folder laid out like the KDCI sample folders."""
    folder = Path(folder).expanduser()
    if not folder.is_dir():
        raise RuntimeError(f"Folder not found: {folder}")
    out = []
    for p in sorted(folder.rglob("*")):
        if not p.is_file() or p.name.startswith(".") or p.name.startswith("._"):
            continue
        rel = str(p.relative_to(folder))
        if any(part.lower() in SKIP_DIRS for part in Path(rel).parts[:-1]):
            continue
        ext = p.suffix.lower()
        if ext not in VIDEO | AUDIO | IMAGE | FONT:
            continue
        out.append((p, rel, guess_category(p, rel)))
    return out


def contact_sheet(src, dst, dur, n=6, w=320):
    step = max(dur / n, 0.2)
    run([which("ffmpeg"), "-v", "error", "-y", "-i", str(src), "-vf",
         f"fps=1/{step:.3f},scale={w}:-2,tile={n}x1", "-frames:v", "1", "-q:v", "4", str(dst)], check=False)


def ingest(job, files):
    """files: list of (src_path, original_name, category or None). Copies into the job and probes."""
    seen = {}
    items = []
    vids_unknown = []
    for src, orig, cat in files:
        src = Path(src)
        name = slug(orig)
        base, ext = name[: -len(Path(name).suffix) or None], Path(name).suffix
        k = name
        i = 2
        while k in seen:
            k = f"{base}_{i}{ext}"; i += 1
        seen[k] = 1
        dst = job.assets / k
        if src.resolve() != dst.resolve():
            shutil.copy2(src, dst)
        it = {"id": k, "name": orig, "cat": cat, "path": str(dst)}
        ext = dst.suffix.lower()
        if ext in VIDEO:
            try:
                it.update(video_info(dst))
            except Exception as e:
                it["error"] = str(e)
            if cat is None:
                vids_unknown.append(it)
        elif ext in IMAGE:
            im = Image.open(dst)
            it.update(width=im.width, height=im.height, alpha=(im.mode in ("RGBA", "LA", "P") and _has_alpha(im)))
            it["kind"] = "icon" if it["alpha"] else "photo"
        elif ext in AUDIO:
            try:
                it.update(video_info(dst))
            except Exception:
                pass
        items.append(it)
        job.check_cancel()
    # resolve unknown videos: longest vertical clip with audio -> raw, rest -> broll
    have_raw = any(i["cat"] == "raw" for i in items)
    if vids_unknown:
        cand = sorted([v for v in vids_unknown if v.get("has_audio")], key=lambda v: -v.get("duration", 0))
        for v in vids_unknown:
            if not have_raw and cand and v is cand[0] and v.get("height", 0) >= v.get("width", 1):
                v["cat"] = "raw"; have_raw = True
            elif v.get("alpha") and abs(v.get("height", 0) - 1920) < 4:
                v["cat"] = "endcard"
            else:
                v["cat"] = "broll"
    # thumbnails
    th = job.dir / "thumbs"
    th.mkdir(exist_ok=True)
    for it in items:
        p = Path(it["path"])
        ext = p.suffix.lower()
        t = th / (p.stem + ".jpg")
        if ext in VIDEO and it["cat"] in ("broll", "raw", "endcard"):
            contact_sheet(p, t, it.get("duration", 5), n=6 if it["cat"] == "broll" else 8)
        elif ext in IMAGE:
            im = Image.open(p).convert("RGBA")
            im.thumbnail((360, 360))
            bg = Image.new("RGB", im.size, (120, 120, 120))
            bg.paste(im, (0, 0), im)
            bg.save(t, quality=85)
        if t.exists():
            it["thumb"] = f"thumbs/{t.name}"
    job.state["assets"] = {it["id"]: it for it in items}
    job.save()
    return items


def _has_alpha(im):
    im = im.convert("RGBA")
    a = im.getchannel("A")
    return a.getextrema()[0] < 250


def by_cat(job, cat):
    return [a for a in job.state["assets"].values() if a.get("cat") == cat]


def one(job, cat, required=False):
    xs = by_cat(job, cat)
    if not xs:
        if required:
            raise RuntimeError(f"Missing asset: {cat}")
        return None
    return max(xs, key=lambda a: a.get("duration", 0)) if cat == "raw" else xs[0]


def validate(job):
    errs = []
    if not by_cat(job, "raw"):
        errs.append("Add the raw talking-head clip (vertical video with speech).")
    if len(by_cat(job, "raw")) > 1:
        errs.append("Only one raw clip per reel is supported - move extra takes into B-roll or remove them.")
    return errs

"""Edit planning. Claude reads the raw transcript (with word indices and pause markers)
plus contact sheets of every asset and returns a structured edit plan through a tool call.
A rule-based fallback is used when no API key is configured."""
import base64, json, re
from pathlib import Path

GUIDE = (Path(__file__).parent / "plan_guide.md").read_text()
EXAMPLE = (Path(__file__).parent / "plan_example.json").read_text()

EL = {
    "type": "object",
    "properties": {
        "kind": {"type": "string", "enum": ["headline", "text", "chip", "pill", "image", "arrow", "logo"]},
        "text": {"type": "string"},
        "style": {"type": "string", "enum": ["white", "red", "muted", "struck", "redline"]},
        "size": {"type": "string", "enum": ["s", "m", "l", "xl"]},
        "image": {"type": "string", "description": "asset id of an image (photo -> round avatar, transparent PNG -> icon)"},
        "mark": {"type": "string", "enum": ["check", "cross", ""]},
        "at": {"type": "integer", "description": "word index whose start triggers the pop-in"},
        "hide_at": {"type": "integer"},
        "strike_at": {"type": "integer"},
        "sfx": {"type": "boolean"},
        "weight": {"type": "string", "enum": ["semibold", "bold"], "description": "Inter weight for text and chip elements (default semibold)"},
    },
    "required": ["kind"],
}
SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string", "description": "Reel title for the file name, Title Case, <= 60 chars"},
        "summary": {"type": "string", "description": "2-4 sentences describing the edit for the reviewer"},
        "keep": {"type": "array", "items": {"type": "array", "items": {"type": "integer"}, "minItems": 2, "maxItems": 2},
                 "description": "inclusive [first,last] word-index ranges to KEEP; drop false starts, flubbed retakes, off-script asides"},
        "shots": {"type": "array", "items": {"type": "object", "properties": {
            "at": {"type": "integer"}, "type": {"type": "string", "enum": ["aroll", "broll"]},
            "zoom": {"type": "number"}, "blur": {"type": "boolean"},
            "asset": {"type": "string"}, "src_start": {"type": "number"}, "fx": {"type": "number"},
            "look": {"type": "string", "enum": ["none", "crimson", "brand_red", "dark", "mono"]},
            "flip": {"type": "boolean"}, "sfx": {"type": "string", "enum": ["none", "typing"]}},
            "required": ["at", "type"]}},
        "graphics": {"type": "array", "items": {"type": "object", "properties": {
            "template": {"type": "string", "enum": ["card", "stat", "chat", "stack", "cta"]},
            "from": {"type": "integer"}, "to": {"type": "integer"},
            "hide_captions": {"type": "boolean"},
            "placement": {"type": "string", "enum": ["behind_head", "center", "top"]},
            "align": {"type": "string", "enum": ["center", "left"]},
            "tag": {"type": "string"},
            "rows": {"type": "array", "items": {"type": "array", "items": EL}},
            "number": {"type": "string"}, "label": {"type": "string"}, "sub": {"type": "string"},
            "sub_highlight": {"type": "array", "items": {"type": "string"}},
            "at_number": {"type": "integer"}, "at_label": {"type": "integer"}, "at_sub": {"type": "integer"},
            "title": {"type": "string"}, "at_title": {"type": "integer"}, "window_title": {"type": "string"},
            "messages": {"type": "array", "items": {"type": "object", "properties": {
                "role": {"type": "string", "enum": ["customer", "bot", "agent", "system"]},
                "name": {"type": "string"}, "text": {"type": "string"}, "at": {"type": "integer"},
                "avatar": {"type": "string"}}, "required": ["role", "text"]}},
            "items": {"type": "array", "items": {"type": "object", "properties": {
                "text": {"type": "string"}, "style": {"type": "string", "enum": ["glass", "red"]},
                "at": {"type": "integer"}, "sfx": {"type": "boolean"},
                "weight": {"type": "string", "enum": ["semibold", "bold"]}}, "required": ["text"]}},
            "url": {"type": "string"}, "at_url": {"type": "integer"}},
            "required": ["template", "from", "to"]}},
        "keywords": {"type": "array", "items": {"type": "integer"}, "description": "word indices shown on the red caption pill"},
        "avatars": {"type": "object", "description": "optional crop per photo asset id: {cx,cy,size} as 0-1 fractions of width/height(size of min side)",
                    "additionalProperties": {"type": "object", "properties": {"cx": {"type": "number"}, "cy": {"type": "number"}, "size": {"type": "number"}}}},
    },
    "required": ["title", "summary", "keep", "shots", "graphics", "keywords"],
}


def transcript_text(words):
    out = []
    for i, w in enumerate(words):
        if i and w["s"] - words[i - 1]["s"] > 1.2:
            out.append(f"  ⟨pause {w['s'] - words[i-1]['s']:.1f}s⟩\n")
        out.append(f"[{i}]{w['w']} ")
        if w["w"][-1:] in ".?!":
            out.append(f"  ({w['s']:.1f}s)\n")
    return "".join(out)


def asset_blocks(job):
    blocks, lines = [], []
    for aid, a in job.state["assets"].items():
        cat = a.get("cat")
        if cat in ("broll", "images"):
            d = f"- `{aid}` ({cat}"
            if cat == "broll":
                d += f", {a.get('duration', 0):.1f}s, {a.get('width')}x{a.get('height')}"
            else:
                d += f", {a.get('kind')}, {a.get('width')}x{a.get('height')}"
            d += f") original name: {a.get('name')}"
            lines.append(d)
            th = job.dir / a.get("thumb", "") if a.get("thumb") else None
            if th and th.exists():
                blocks.append({"type": "text", "text": f"Asset `{aid}` ({cat}):"})
                blocks.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                                            "data": base64.b64encode(th.read_bytes()).decode()}})
    others = [f"- {a['cat']}: `{aid}` ({a.get('name')})" for aid, a in job.state["assets"].items() if a.get("cat") not in ("broll", "images")]
    return lines, others, blocks


def claude_plan(job, words, cfg, notes="", previous=None):
    import anthropic
    client = anthropic.Anthropic(api_key=cfg["api_key"])
    lines, others, blocks = asset_blocks(job)
    raw_thumb = next((a.get("thumb") for a in job.state["assets"].values() if a.get("cat") == "raw"), None)
    content = [{"type": "text", "text": GUIDE.replace("{{URL}}", cfg.get("brand_url") or "kdci.co")}]
    content.append({"type": "text", "text": "Example plan from a previous KDCI reel (house style, different script):\n```json\n" + EXAMPLE + "\n```"})
    if raw_thumb and (job.dir / raw_thumb).exists():
        content.append({"type": "text", "text": "Contact sheet of the raw talking-head clip:"})
        content.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                                     "data": base64.b64encode((job.dir / raw_thumb).read_bytes()).decode()}})
    content += blocks
    content.append({"type": "text", "text": "Available B-roll and images:\n" + "\n".join(lines or ["(none)"]) +
                    "\nOther assets (used automatically):\n" + "\n".join(others)})
    content.append({"type": "text", "text": "Raw transcript (word index in brackets, sentence end times in parentheses):\n" + transcript_text(words)})
    if previous:
        content.append({"type": "text", "text": "Current plan (revise it):\n```json\n" + json.dumps(previous)[:60000] + "\n```"})
    if notes:
        content.append({"type": "text", "text": "Reviewer notes - follow these:\n" + notes})
    content.append({"type": "text", "text": "Now call submit_plan with the full edit plan."})
    model = cfg.get("model") or pick_model(client)
    job.log(f"Planning with {model}")
    msg = client.messages.create(
        model=model, max_tokens=16000,
        tools=[{"name": "submit_plan", "description": "Submit the reel edit plan", "input_schema": SCHEMA}],
        tool_choice={"type": "tool", "name": "submit_plan"},
        messages=[{"role": "user", "content": content}])
    for b in msg.content:
        if getattr(b, "type", "") == "tool_use":
            return b.input
    raise RuntimeError("Claude did not return a plan")


def list_models(api_key):
    import anthropic
    c = anthropic.Anthropic(api_key=api_key)
    return [m.id for m in c.models.list(limit=50).data]


def pick_model(client):
    ids = [m.id for m in client.models.list(limit=50).data]
    for pref in ("opus", "sonnet"):
        for i in ids:
            if pref in i:
                return i
    return ids[0]


# ---------------------------------------------------------------- fallback
def heuristic_plan(job, words, url="kdci.co"):
    """No-API plan: keep everything, alternate zooms per sentence, spread B-roll, hook + CTA cards."""
    n = len(words)
    sents, st = [], 0
    for i, w in enumerate(words):
        if w["w"][-1:] in ".?!" or i == n - 1:
            sents.append((st, i)); st = i + 1
    brolls = [a for a in job.state["assets"].values() if a.get("cat") == "broll"]
    shots, zooms = [], [1.0, 1.15]
    b_at = set()
    if brolls and len(sents) > 3:
        step = max(1, (len(sents) - 2) // (len(brolls) + 1))
        for k, b in enumerate(brolls):
            si = 1 + step * (k + 1)
            if si < len(sents) - 1:
                b_at.add(si)
    bi = 0
    for k, (a, b) in enumerate(sents):
        if k in b_at and bi < len(brolls):
            br = brolls[bi]; bi += 1
            shots.append({"at": a, "type": "broll", "asset": br["id"], "src_start": 0, "fx": 0.5,
                          "sfx": "typing" if re.search(r"typ|keyboard", br["name"].lower()) else "none"})
            if b - a > 8:
                shots.append({"at": a + (b - a) // 2, "type": "aroll", "zoom": 1.15})
        else:
            shots.append({"at": a, "type": "aroll", "zoom": zooms[k % 2] if k else 1.0})
    kws = [i for i, w in enumerate(words) if re.search(r"\d|kdci|\bai\b", w["w"].lower())]
    first = sents[0]
    hook = " ".join(w["w"] for w in words[first[0]:first[1] + 1])
    hook = " ".join(hook.split()[:7])
    graphics = [{"template": "card", "from": first[0], "to": first[1], "placement": "behind_head", "hide_captions": True,
                 "rows": [[{"kind": "headline", "text": hook.upper(), "size": "m"}]]}]
    last = sents[-1]
    m = next((w["w"].strip(".,") for w in words[last[0]:] if re.search(r"\w\.\w{2,}", w["w"])), url)
    graphics.append({"template": "cta", "from": last[0], "to": last[1], "placement": "behind_head", "hide_captions": True,
                     "rows": [[{"kind": "headline", "text": " ".join(w["w"] for w in words[last[0]:last[1] + 1]).replace(m, "").strip(" .,").removesuffix(" at").strip(), "size": "s"}]],
                     "url": m, "at_url": last[1]})
    title = " ".join(w[:1].upper() + w[1:] for w in hook.strip(" .,!?").split())
    return {"title": title[:60] or "KDCI Reel", "summary": "Rule-based draft (no Claude API key): all speech kept, "
            "dead air removed, zooms alternate per sentence, B-roll spread evenly, hook and CTA cards.",
            "keep": [[0, n - 1]], "shots": shots, "graphics": graphics, "keywords": kws}


# ---------------------------------------------------------------- validation
def normalize(plan, words, assets):
    n = len(words)
    clamp = lambda i: max(0, min(n - 1, int(i)))
    keep = []
    for r in plan.get("keep") or [[0, n - 1]]:
        if isinstance(r, (list, tuple)) and len(r) == 2:
            a, b = clamp(r[0]), clamp(r[1])
            if b >= a: keep.append([a, b])
    keep.sort()
    merged = []
    for a, b in keep:
        if merged and a <= merged[-1][1] + 1: merged[-1][1] = max(merged[-1][1], b)
        else: merged.append([a, b])
    plan["keep"] = merged or [[0, n - 1]]
    kept = set()
    for a, b in plan["keep"]: kept.update(range(a, b + 1))
    first_kept = plan["keep"][0][0]

    def snap(i):
        i = clamp(i)
        if i in kept: return i
        later = [k for k in sorted(kept) if k >= i]
        return later[0] if later else max(kept)
    shots = []
    for s in plan.get("shots", []):
        s = dict(s); s["at"] = snap(s.get("at", 0))
        if s.get("type") == "broll" and s.get("asset") not in assets:
            continue
        shots.append(s)
    shots.sort(key=lambda s: s["at"])
    if not shots or shots[0]["at"] > first_kept or shots[0].get("type") != "aroll":
        shots.insert(0, {"at": first_kept, "type": "aroll", "zoom": 1.0})
    shots[0]["at"] = first_kept
    plan["shots"] = shots
    gs = []
    for g in plan.get("graphics", []):
        g = dict(g)
        g["from"] = snap(g.get("from", 0)); g["to"] = max(g["from"], snap(g.get("to", g["from"])))
        for key in ("at_number", "at_label", "at_sub", "at_title", "at_url"):
            if g.get(key) is not None: g[key] = snap(g[key])
        for row in g.get("rows") or []:
            for el in row:
                for key in ("at", "hide_at", "strike_at"):
                    if el.get(key) is not None: el[key] = snap(el[key])
                if el.get("image") and el["image"] not in assets: el.pop("image")
        for m in g.get("messages") or []:
            if m.get("at") is not None: m["at"] = snap(m["at"])
            if m.get("avatar") and m["avatar"] not in assets: m.pop("avatar")
        for it in g.get("items") or []:
            if it.get("at") is not None: it["at"] = snap(it["at"])
        gs.append(g)
    plan["graphics"] = gs
    plan["keywords"] = [clamp(i) for i in plan.get("keywords", [])]
    plan["title"] = re.sub(r'[\\/:*?"<>|]+', "", plan.get("title") or "KDCI Reel").strip()[:70] or "KDCI Reel"
    return plan

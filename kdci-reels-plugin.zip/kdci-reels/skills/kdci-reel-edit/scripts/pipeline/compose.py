"""Turns the edit plan into a HyperFrames composition (index.html): glass panels,
chat UIs, stat cards, chip stacks, CTA, plus karaoke captions. Also returns the
SFX pop times, caption-hidden windows and the matte windows needed downstream."""
import html, json, os, re, shutil
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
from .common import VENDOR, FPS
from .base import word_T

CSS = (Path(__file__).parent / "composition.css").read_text()
SIZES = {
    "headline": {"s": 52, "m": 66, "l": 84, "xl": 104},
    "text": {"s": 34, "m": 44, "l": 52, "xl": 60},
    "chip": {"s": 32, "m": 38, "l": 44, "xl": 52},
    "pill": {"s": 34, "m": 44, "l": 64, "xl": 96},
    "image": {"s": 84, "m": 104, "l": 124, "xl": 160},
    "arrow": {"s": 48, "m": 64, "l": 84, "xl": 104},
}
FUNC = {"a", "an", "the", "of", "to", "and", "that", "on", "at", "is", "have", "in", "for", "with", "your", "our"}
esc = lambda s: html.escape(str(s or ""))


def norm(w):
    return re.sub(r"[^\w%.]", "", w.lower()).strip(".")


# ---------------------------------------------------------------- image prep
def prep_images(job, plan, hfa):
    """Avatar circles for photos, white-recoloured icons for dark line icons, KDCI mark from the end card."""
    out = {}
    hints = plan.get("avatars") or {}
    for aid, a in job.state["assets"].items():
        if a.get("cat") != "images":
            continue
        im = Image.open(a["path"]).convert("RGBA")
        if a.get("kind") == "photo":
            h = hints.get(aid) or {}
            W, H = im.size
            side = int(min(W, H) * float(h.get("size", 0.72)))
            cx, cy = float(h.get("cx", 0.5)) * W, float(h.get("cy", 0.38)) * H
            x0 = int(min(max(cx - side / 2, 0), W - side)); y0 = int(min(max(cy - side / 2, 0), H - side))
            c = im.crop((x0, y0, x0 + side, y0 + side)).resize((360, 360), Image.LANCZOS)
            m = Image.new("L", (1440, 1440), 0); ImageDraw.Draw(m).ellipse((0, 0, 1439, 1439), fill=255)
            c.putalpha(m.resize((360, 360), Image.LANCZOS))
            fn = f"av_{Path(aid).stem}.png"; c.save(hfa / fn)
            out[aid] = {"src": f"assets/{fn}", "kind": "avatar"}
        else:
            arr = np.array(im)
            op = arr[..., 3] > 128
            dark = op.any() and arr[..., :3][op].mean() < 70
            if dark:   # black line icon -> white so it reads on dark glass
                w = Image.new("RGBA", im.size, (255, 255, 255, 0)); w.putalpha(im.getchannel("A")); im = w
            im.thumbnail((512, 512))
            fn = f"ic_{Path(aid).stem}.png"; im.save(hfa / fn)
            out[aid] = {"src": f"assets/{fn}", "kind": "icon"}
    # KDCI mark (red circle) from the end card if present
    ec = next((a for a in job.state["assets"].values() if a.get("cat") == "endcard"), None)
    if ec:
        try:
            import subprocess
            from .common import which
            png = job.p("ec5.png")
            subprocess.run([which("ffmpeg"), "-v", "error", "-y", "-ss", str(min(5, max(0, ec.get("duration", 6) / 2))),
                            "-i", ec["path"], "-frames:v", "1", "-pix_fmt", "rgba", png], check=True)
            e = np.array(Image.open(png).convert("RGBA"))
            m = (e[..., 0] > 180) & (e[..., 1] < 90) & (e[..., 2] < 110) & (e[..., 3] > 200)
            if m.sum() > 5000:
                ys, xs = np.where(m)
                side = max(xs.max() - xs.min(), ys.max() - ys.min()) + 6
                cx, cy = (xs.max() + xs.min()) // 2, (ys.max() + ys.min()) // 2
                c = Image.open(png).convert("RGBA").crop((cx - side // 2, cy - side // 2, cx + side // 2, cy + side // 2)).resize((300, 300), Image.LANCZOS)
                mk = Image.new("L", (1200, 1200), 0); ImageDraw.Draw(mk).ellipse((0, 0, 1199, 1199), fill=255)
                c.putalpha(mk.resize((300, 300), Image.LANCZOS)); c.save(hfa / "kdci_mark.png")
                out["@kdci"] = {"src": "assets/kdci_mark.png", "kind": "avatar"}
        except Exception as ex:
            job.log(f"KDCI mark extraction skipped: {ex}")
    return out


# ---------------------------------------------------------------- captions
def caption_chunks(wT, hide, maxc=20):
    def hidden(t): return any(a - 0.05 <= t < b for a, b in hide)
    W = []
    for x in wT:
        if W and W[-1]["w"].lower() == "chat" and x["w"].lower().startswith("bot") and x["s"] - W[-1]["s"] < 0.5:
            W[-1] = dict(W[-1], w="chatbot" + x["w"][3:]); continue
        W.append(dict(x))
    chunks, cur = [], []
    for k, x in enumerate(W):
        if hidden(x["s"]):
            if cur: chunks.append(cur); cur = []
            continue
        cur.append(x)
        nxt = W[k + 1] if k + 1 < len(W) else None
        txt = " ".join(y["w"] for y in cur)
        if (x["w"][-1:] in ".,?!" or len(cur) >= 4 or nxt is None or nxt["s"] - x["s"] > 0.7
                or len(txt + " " + nxt["w"]) > maxc or hidden(nxt["s"])):
            chunks.append(cur); cur = []
    if cur: chunks.append(cur)
    for k in range(len(chunks) - 1):
        c, n = chunks[k], chunks[k + 1]
        while len(c) > 1 and c[-1]["w"].lower() in FUNC and n and n[0]["s"] - c[-1]["s"] < 0.7 and len(n) < 4 and not hidden(n[0]["s"]):
            n.insert(0, c.pop())
    for k in range(len(chunks) - 1):
        c, n = chunks[k], chunks[k + 1]
        if len(n) == 1 and c and len(c) < 4 and n[0]["s"] - c[-1]["s"] < 0.7 and c[-1]["w"][-1:] not in ".,?!" \
                and len(" ".join(y["w"] for y in c + n)) <= maxc + 2:
            c.extend(n); n.clear()
    return [c for c in chunks if c]


# ---------------------------------------------------------------- row fitting
_fonts = {}


def text_w(txt, px, bold):
    from PIL import ImageFont
    key = (bold, px)
    if key not in _fonts:
        f = VENDOR / ("PlusJakartaSans-ExtraBold.ttf" if bold else "Inter-SemiBold.otf")
        _fonts[key] = ImageFont.truetype(str(f), px)
    return _fonts[key].getlength(txt or "")


def el_width(el):
    kind, size = el.get("kind", "text"), el.get("size", "m")
    t = el.get("text", "")
    if kind == "image":
        return SIZES["image"].get(size, 104) + 10
    if kind == "chip":
        px = (SIZES["chip"].get(size, 38))
        return text_w(t, px, False) + px * 1.6 + (px * 1.7 if el.get("image") else 0) + (px * 1.0 if el.get("mark") else 0) + 4
    if kind in ("pill", "logo"):
        px = (SIZES["pill"].get(size, 44))
        return text_w(t or "KDCI", px, True) + px * 1.2 + (px * 1.45 if kind == "logo" else 0)
    if kind == "arrow":
        return SIZES["arrow"].get(size, 64) * 0.45
    px = (SIZES["headline" if kind == "headline" else "text"].get(size, 52))
    return text_w(t, px, kind == "headline") * (0.99 if kind == "headline" else 1.0)


def row_scale(row, avail=840, gap=18):
    w = sum(el_width(e) for e in row) + gap * max(0, len(row) - 1)
    return min(1.0, avail / w) if w > 0 else 1.0


# ---------------------------------------------------------------- composition
class Builder:
    def __init__(self, wT, main, imgs, heads, shots_aroll, bounds):
        self.wT, self.main, self.imgs, self.heads = wT, main, imgs, heads
        self.aroll = shots_aroll
        self.bounds = bounds
        self.G, self.A, self.pops = [], [], []

    def T(self, idx, lead=0.04):
        if idx is None:
            return None
        return round(max(0.0, word_T(self.wT, int(idx)) - lead), 3)

    def pop(self, sel, t, d=.45, fr="scale:.86,y:18", ease="back.out(1.8)"):
        self.A.append(f"tl.fromTo('{sel}',{{opacity:0,{fr}}},{{opacity:1,scale:1,y:0,x:0,duration:{d},ease:'{ease}'}},{t:.3f});")

    def fade(self, sel, t, d=.3):
        self.A.append(f"tl.fromTo('{sel}',{{opacity:0,y:14}},{{opacity:1,y:0,duration:{d},ease:'power2.out'}},{t:.3f});")

    def out(self, sel, t, d=.25):
        self.A.append(f"tl.fromTo('{sel}',{{opacity:1}},{{opacity:0,duration:{d},ease:'power1.in'}},{t:.3f});")

    def mg(self, gid, s, e, body, z=2):
        self.G.append((gid, s, e, body, z)); self.out(f"#{gid} .inner", max(s + 0.3, e - 0.25))

    def img(self, aid, px):
        im = self.imgs.get(aid)
        if not im:
            return ""
        if im["kind"] == "avatar":
            return f'<img class="av" src="{im["src"]}" style="width:{px}px;height:{px}px">'
        return f'<img class="icon" src="{im["src"]}" style="width:{px}px;height:{px}px">'

    # ---- element
    def element(self, gid, eid, el, s0, k, sc=1.0):
        kind = el.get("kind", "text")
        size = el.get("size", "m")
        st = el.get("style", "white")
        txt = esc(el.get("text", ""))
        cls = f"{gid}{eid}"
        if kind == "image":
            px = int(SIZES["image"].get(size, 104) * sc)
            inner = self.img(el.get("image"), px) or ""
            h = f'<span class="{cls}" style="display:inline-flex">{inner}</span>'
        elif kind == "logo":
            px = int(SIZES["pill"].get(size, 44) * sc)
            mark = f'<img src="{self.imgs["@kdci"]["src"]}">' if "@kdci" in self.imgs else ""
            h = f'<span class="pill white {cls}" style="font-size:{px}px;padding:.14em .6em .14em .16em">{mark}{txt or "KDCI"}</span>'
        elif kind == "chip":
            px = int(SIZES["chip"].get(size, 38) * sc)
            icon = ""
            if el.get("image"):
                im = self.imgs.get(el["image"])
                if im: icon = f'<img src="{im["src"]}">'
            mark = {"check": '<span class="ok">✓</span>', "cross": '<span class="x">✕</span>'}.get(el.get("mark", ""), "")
            c2 = {"red": "red", "redline": "redline"}.get(st, "")
            h = f'<span class="chip {c2} {cls}" style="font-size:{px}px">{mark}{icon}{txt}</span>'
        elif kind == "pill":
            px = int(SIZES["pill"].get(size, 44) * sc)
            h = f'<span class="pill {"white" if st == "white" else "red"} {cls}" style="font-size:{px}px">{txt}</span>'
        elif kind == "arrow":
            px = int(SIZES["arrow"].get(size, 64) * sc)
            h = f'<span class="arrow {cls}" style="font-size:{px}px">{txt or "›"}</span>'
        else:
            px = int(SIZES["headline" if kind == "headline" else "text"].get(size, 52) * sc)
            base = "hl" if kind == "headline" else "tx"
            c2 = {"red": "red-t", "muted": "muted-t", "struck": "struck"}.get(st, "")
            strike = '<span class="strike"></span>' if st == "struck" else ""
            h = f'<span class="{base} {c2} {cls}" style="font-size:{px}px">{txt}{strike}</span>'
        if el.get("weight") == "bold" and kind in ("text", "chip"):
            h = h.replace('style="font-size:', 'style="font-weight:700;font-size:', 1)
        t = self.T(el.get("at")) if el.get("at") is not None else s0 + 0.15 + 0.08 * k
        t = max(t, s0 + 0.05)
        if kind in ("headline",) and size in ("l", "xl"):
            self.pop(f".{cls}", t, .5)
        elif kind in ("text",):
            self.fade(f".{cls}", t)
        else:
            self.pop(f".{cls}", t)
        if el.get("sfx"):
            self.pops.append((t, 0.38 if kind != "chip" else 0.28))
        if st == "struck":
            ts = self.T(el.get("strike_at")) if el.get("strike_at") is not None else t + 0.6
            self.A.append(f"tl.fromTo('.{cls} .strike',{{scaleX:0}},{{scaleX:1,duration:.35,ease:'power2.inOut'}},{ts:.3f});")
        if el.get("hide_at") is not None:
            self.out(f".{cls}", self.T(el["hide_at"]))
        return h

    def card(self, gid, g, s, e):
        place = g.get("placement", "behind_head")
        al = g.get("align") or ("left" if place == "top" else "center")
        rows = []
        k = 0
        if g.get("tag"):
            rows.append(f'<div class="row"><span class="tag {gid}tag">{esc(g["tag"])}</span></div>')
            self.pop(f".{gid}tag", s + 0.1)
        for r, row in enumerate(g.get("rows") or []):
            els = []
            sc = row_scale(row)
            for el in row:
                els.append(self.element(gid, f"e{r}_{len(els)}", el, s, k, sc)); k += 1
            rows.append(f'<div class="row" style="flex-wrap:nowrap">{"".join(els)}</div>')
        style = ""
        if place == "behind_head":
            top = int(g.get("top", 84))
            head = self.heads.get(gid, 380)
            style = f"min-height:{max(200, head + 150 - top)}px"
            wrap = f'<div class="place" style="top:{top}px">'
        elif place == "center":
            wrap = '<div class="place center">'
        else:
            wrap = f'<div class="place" style="top:{int(g.get("top", 130))}px">'
        body = f'{wrap}<div class="card al-{al}" style="{style}">{"".join(rows)}</div></div>'
        self.A.append(f"tl.fromTo('#{gid} .card',{{opacity:0,y:-30,scale:.96}},{{opacity:1,y:0,scale:1,duration:.5,ease:'power3.out'}},{s:.3f});")
        return body

    def build(self, plan):
        hide = []
        matte_windows = {}
        gs = sorted(plan.get("graphics", []), key=lambda g: g.get("from", 0))
        spans = []
        for n, g in enumerate(gs):
            s = self.T(g.get("from"), lead=0.15)
            to = g.get("to", g.get("from"))
            nxt = [w for w in self.wT if w["i"] > int(to)]
            e = round(nxt[0]["s"] - 0.05, 3) if nxt else self.main
            for b in self.bounds:
                if abs(b - s) < 0.25: s = b
                if abs(b - e) < 0.25: e = b
            spans.append([s, max(e, s + 0.8)])
        for n in range(len(spans) - 1):
            if spans[n][1] > spans[n + 1][0]:
                spans[n][1] = max(spans[n][0] + 0.5, spans[n + 1][0])
        for n, (g, (s, e)) in enumerate(zip(gs, spans)):
            e = min(e, self.main)
            gid = f"g{n+1}"
            g["_id"] = gid
            g["_span"] = [s, e]
            tpl = g.get("template", "card")
            if g.get("hide_captions"):
                hide.append((s, e))
            if tpl in ("card", "cta") and g.get("placement", "behind_head") == "behind_head":
                matte_windows[gid] = (s, e)
            if tpl == "card":
                self.mg(gid, s, e, self.card(gid, g, s, e))
            elif tpl == "cta":
                self.mg(gid, s, e, self.card(gid, g, s, e))
                ta = self.T(g.get("at_url")) if g.get("at_url") is not None else max(s + 0.5, e - 2.0)
                url = esc(g.get("url") or "kdci.co")
                self.mg(gid + "u", s, e, f'<div class="ctaw"><div class="pill red cta">{url}</div></div>', z=5)
                self.A.append(f"tl.fromTo('#{gid}u .cta',{{opacity:0,scale:.6}},{{opacity:1,scale:1,duration:.55,ease:'back.out(2)'}},{ta:.3f});")
                if e - ta > 1.4:
                    self.A.append(f"tl.fromTo('#{gid}u .cta',{{scale:1}},{{scale:1.06,duration:.5,yoyo:true,repeat:1,ease:'sine.inOut'}},{ta+0.65:.3f});")
                self.pops.append((ta, 0.4))
            elif tpl == "stat":
                sub = esc(g.get("sub", ""))
                for hl in g.get("sub_highlight", []) or []:
                    sub = sub.replace(esc(hl), f'<span class="kwp">{esc(hl)}</span>', 1)
                top = int(g.get("top", 300))
                body = (('<div class="glow"></div>' if g.get("glow", True) else "") +
                        f'<div class="place" style="top:{top}px"><div class="card stat al-left">' +
                        (f'<div class="row"><span class="tag t">{esc(g.get("tag"))}</span></div>' if g.get("tag") else "") +
                        f'<div class="num">{esc(g.get("number"))}</div><div class="lab">{esc(g.get("label", ""))}</div>' +
                        (f'<div class="sub">{sub}</div>' if sub else "") + "</div></div>")
                self.mg(gid, s, e, body)
                self.fade(f"#{gid} .glow", s, .6)
                self.pop(f"#{gid} .card", s + .05, .5, "scale:.94,y:30", "power3.out")
                if g.get("tag"): self.pop(f"#{gid} .t", s + .35)
                tn = self.T(g.get("at_number")) if g.get("at_number") is not None else s + .6
                self.A.append(f"tl.fromTo('#{gid} .num',{{opacity:0,scale:.5}},{{opacity:1,scale:1,duration:.6,ease:'back.out(2)'}},{tn:.3f});")
                self.pops.append((tn, 0.4))
                self.fade(f"#{gid} .lab", self.T(g.get("at_label")) if g.get("at_label") is not None else tn + .6)
                if sub: self.fade(f"#{gid} .sub", self.T(g.get("at_sub")) if g.get("at_sub") is not None else tn + 1.2)
            elif tpl == "stack":
                items = []
                for k, it in enumerate(g.get("items", [])[:6]):
                    c2 = "red" if it.get("style") == "red" else ""
                    fw = ' style="font-weight:700"' if it.get("weight") == "bold" else ""
                    items.append(f'<span class="chip {c2} {gid}i{k}"{fw}>{esc(it.get("text"))}</span>')
                    t = self.T(it.get("at")) if it.get("at") is not None else s + 0.3 + 0.4 * k
                    self.pop(f".{gid}i{k}", t)
                    if it.get("sfx"): self.pops.append((t, 0.28))
                tag = f'<span class="tag {gid}t">{esc(g["tag"])}</span>' if g.get("tag") else ""
                if tag: self.pop(f".{gid}t", s + 0.1)
                self.mg(gid, s, e, f'<div class="stack" style="top:{int(g.get("top", 130))}px">{tag}{"".join(items)}</div>')
            elif tpl == "chat":
                rows = []
                for k, m in enumerate(g.get("messages", [])[:6]):
                    role = m.get("role", "customer")
                    if role == "system":
                        rows.append(f'<div class="sys m{k}">{esc(m.get("text"))}</div>')
                    elif role == "customer":
                        rows.append(f'<div class="msg r m{k}"><div class="bub customer">{esc(m.get("text"))}</div></div>')
                    else:
                        av = self.img(m.get("avatar"), 84).replace('class="av"', 'class="av sm"') if m.get("avatar") else ""
                        nm = esc(m.get("name") or ("Support Bot" if role == "bot" else "Agent"))
                        rows.append(f'<div class="msg l m{k}">{av}<div><div class="nm">{nm}</div>'
                                    f'<div class="bub {"bot" if role == "bot" else "agent"}">{esc(m.get("text"))}</div></div></div>')
                body = (f'<div class="ctitle">' + (f'<span class="tag">{esc(g.get("tag"))}</span>' if g.get("tag") else "") +
                        f'<div class="hl" style="font-size:{int(g.get("title_size", 96))}px;margin-top:18px;line-height:1">{esc(g.get("title", ""))}</div></div>'
                        f'<div class="card chatwin"><div class="chead"><span class="dot"></span>{esc(g.get("window_title") or "Customer Support")}'
                        f'<span class="live">online</span></div><div class="thread">{"".join(rows)}</div></div>')
                self.mg(gid, s, e, body)
                self.A.append(f"tl.fromTo('#{gid} .chatwin',{{opacity:0,y:60}},{{opacity:1,y:0,duration:.5,ease:'power3.out'}},{s + .05:.3f});")
                if g.get("tag"): self.pop(f"#{gid} .ctitle .tag", s + 0.15)
                self.pop(f"#{gid} .ctitle .hl", self.T(g.get("at_title")) if g.get("at_title") is not None else s + 0.3)
                for k, m in enumerate(g.get("messages", [])[:6]):
                    t = self.T(m.get("at")) if m.get("at") is not None else s + 0.6 + 0.9 * k
                    fr = "scale:.85,y:30" + (",x:40" if m.get("role") == "customer" else ",x:-40" if m.get("role") != "system" else "")
                    self.pop(f"#{gid} .m{k}", t, .4, fr)
        return hide, matte_windows


def build(job, plan, wT, main, heads, bounds, aroll, with_person, kw_idx):
    hfd = job.hf
    hfa = hfd / "assets"
    hfa.mkdir(parents=True, exist_ok=True)
    for f in ("gsap.min.js", "Inter-SemiBold.otf", "Inter-Bold.otf", "PlusJakartaSans-ExtraBold.ttf"):
        if not (hfa / f).exists():
            shutil.copy2(VENDOR / f, hfa / f)
    font = next((a for a in job.state["assets"].values() if a.get("cat") == "font" and "jakarta" in a["name"].lower()), None)
    if font:
        shutil.copy2(font["path"], hfa / "PlusJakartaSans-ExtraBold.ttf")
    _link(job.p("base.mp4"), hfa / "base.mp4")
    if with_person:
        _link(job.p("person.mov"), hfa / "person.mov")
    imgs = prep_images(job, plan, hfa)
    b = Builder(wT, main, imgs, heads, aroll, bounds)
    hide, mw = b.build(plan)
    # captions
    kw = set(int(i) for i in kw_idx or [])
    caph = []
    chunks = caption_chunks(wT, hide)
    for k, c in enumerate(chunks):
        s = c[0]["s"]
        nx = chunks[k + 1][0]["s"] if k + 1 < len(chunks) else main
        e = min(nx, c[-1]["s"] + 0.9, main)
        for a, z in hide:
            if s < a < e: e = a
        e = max(e, s + 0.3)
        spans = []
        for j, x in enumerate(c):
            cls = "cw kw" if x["i"] in kw else "cw"
            spans.append(f'<span class="{cls}" id="c{k}w{j}">{esc(x["w"])}</span>')
            b.A.append(f"tl.fromTo('#c{k}w{j}',{{opacity:.55}},{{opacity:1,duration:.08}},{max(s, x['s']):.3f});")
        caph.append(f'<div class="cap clip" id="cap{k}" data-start="{s:.3f}" data-duration="{e - s:.3f}" data-track-index="9">'
                    f'<div class="ci">{" ".join(spans)}</div></div>')
        b.A.append(f"tl.fromTo('#cap{k} .ci',{{scale:.9}},{{scale:1,duration:.25,ease:'back.out(2)'}},{s:.3f});")
    mgh = "".join(f'<div class="mg clip" id="{gid}" data-start="{s:.3f}" data-duration="{e - s:.3f}" data-track-index="{2 + i % 3}" '
                  f'style="z-index:{z}"><div class="inner">{body}</div></div>' for i, (gid, s, e, body, z) in enumerate(b.G))
    person = (f'<video id="personvid" class="clip" src="assets/person.mov" muted playsinline data-start="0" data-duration="{main}" '
              f'data-track-index="1"></video>') if with_person else ""
    page = f'''<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080, height=1920">
<script src="assets/gsap.min.js"></script>
<style>{CSS}</style></head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{main}" data-width="1080" data-height="1920">
<video id="basevid" class="clip" src="assets/base.mp4" muted playsinline data-start="0" data-duration="{main}" data-track-index="0"></video>
{mgh}
{person}
{"".join(caph)}
</div>
<script>
window.__timelines = window.__timelines || {{}};
const tl = gsap.timeline({{paused:true}});
{chr(10).join(b.A)}
window.__timelines["main"] = tl;
tl.seek(0);
</script></body></html>'''
    (hfd / "index.html").write_text(page)
    if not (hfd / "hyperframes.json").exists():
        (hfd / "hyperframes.json").write_text(json.dumps({
            "$schema": "https://hyperframes.heygen.com/schema/hyperframes.json",
            "registry": "https://raw.githubusercontent.com/heygen-com/hyperframes/main/registry",
            "paths": {"blocks": "compositions", "components": "compositions/components", "assets": "assets"},
            "media": {"autoProxy": True}}, indent=2))
    if not (hfd / "meta.json").exists():
        (hfd / "meta.json").write_text(json.dumps({"id": job.id, "name": job.id}))
    return {"pops": b.pops, "hide": hide, "matte_windows": mw, "graphics": plan.get("graphics", [])}


def _link(src, dst):
    dst = Path(dst)
    if dst.exists() or dst.is_symlink():
        dst.unlink()
    try:
        os.link(src, dst)
    except Exception:
        shutil.copy2(src, dst)

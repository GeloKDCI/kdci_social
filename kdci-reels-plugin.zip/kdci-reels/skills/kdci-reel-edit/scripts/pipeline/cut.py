"""Dead-air removal. Turns the plan's kept word ranges into a list of raw-time keeps,
removes pauses and sentence-end breaths, and maps raw time -> cut timeline (T)."""
import json
import numpy as np


def speech_threshold(db):
    floor = np.percentile(db, 10)
    peak = np.percentile(db, 95)
    # between the noise floor and speech level; matches -39 dB on a -45 floor recording
    return max(floor + 6, min(peak - 18, -39 if floor > -55 else floor + 30))


def regions_from_keep(words, keep, db):
    """keep: [[i0,i1],...] inclusive word index ranges. Returns raw-time regions."""
    n = len(db)
    thr = speech_threshold(db)
    out = []
    for i0, i1 in keep:
        i0 = max(0, int(i0)); i1 = min(len(words) - 1, int(i1))
        if i1 < i0:
            continue
        s = max(0.0, words[i0]["s"] - 0.12)
        if i0 > 0:
            s = max(s, words[i0 - 1]["s"] + 0.15)
        nxt = words[i1 + 1]["s"] if i1 + 1 < len(words) else n / 100
        # end of speech after the last kept word's start, before the next word
        j = int(words[i1]["s"] * 100) + 15
        lim = int(max(nxt - 0.06, words[i1]["s"] + 0.25) * 100)
        last = j
        for k in range(j, min(lim, n)):
            if db[k] > thr:
                last = k
            elif k - last > 40:
                break
        e = min((last + 1) / 100 + 0.12, nxt - 0.04 if i1 + 1 < len(words) else n / 100)
        out.append([round(s, 3), round(max(e, s + 0.2), 3)])
    return out


def compute_keeps(words, keep, db, min_sil=0.22, pre=0.10, post=0.08):
    thr = speech_threshold(db)
    m = db > thr
    md = m.copy()
    for s in range(1, 4):
        md[s:] |= m[:-s]; md[:-s] |= m[s:]
    keeps = []
    for r0, r1 in regions_from_keep(words, keep, db):
        i0, i1 = int(r0 * 100), int(r1 * 100)
        seg = md[i0:i1]
        runs, inr, st = [], False, 0
        for j, v in enumerate(seg):
            if v and not inr: st, inr = j, True
            if not v and inr: runs.append([st, j]); inr = False
        if inr: runs.append([st, len(seg)])
        if not runs:
            continue
        mr = [runs[0]]
        for a, b in runs[1:]:
            if a - mr[-1][1] < int(min_sil * 100): mr[-1][1] = b
            else: mr.append([a, b])
        for a, b in mr:
            s = max((i0 + a) / 100 - pre, r0); e = min((i0 + b) / 100 + post, r1)
            if e - s > 0.12: keeps.append([s, e])
    keeps.sort()
    out = [keeps[0]] if keeps else []
    for s, e in keeps[1:]:
        if s <= out[-1][1] + 0.01: out[-1][1] = max(out[-1][1], e)
        else: out.append([s, e])

    def cutrange(a, b):
        nonlocal out
        n = []
        for s, e in out:
            if e <= a or s >= b: n.append([s, e])
            else:
                if s < a: n.append([s, a])
                if e > b: n.append([b, e])
        out = n
    # breath trim at sentence ends
    br = thr + 6
    for x, y in zip(words, words[1:]):
        if y["s"] - x["s"] > 0.6 and x["w"] and x["w"][-1] in ".,?!":
            i = int((x["s"] + 0.30) * 100); j = int(y["s"] * 100) - 5
            best = (0, 0); cs = None
            for q in range(i, min(j, len(db))):
                if db[q] < br:
                    if cs is None: cs = q
                    if q + 1 - cs > best[1] - best[0]: best = (cs, q + 1)
                else:
                    cs = None
            if best[1] - best[0] >= 18:
                cutrange(best[0] / 100 + 0.10, best[1] / 100 - 0.08)
    return [[round(s, 3), round(e, 3)] for s, e in out if e - s > 0.05]


class Timeline:
    def __init__(self, keeps):
        self.keeps = keeps
        self.cum = []
        acc = 0.0
        for s, e in keeps:
            self.cum.append((acc, acc + e - s, s, e)); acc += e - s
        self.main = round(acc, 3)
        self.bounds = [c[0] for c in self.cum] + [self.main]

    def raw2T(self, r):
        """Raw time -> cut time. Times inside a removed gap snap to the next kept piece."""
        for a, b, s, e in self.cum:
            if r < s:
                return a
            if r <= e:
                return a + (r - s)
        return self.main

    def T2raw(self, T):
        for a, b, s, e in self.cum:
            if a - 1e-6 <= T < b - 1e-6:
                return s + (T - a)
        return self.cum[-1][3]

    def words_T(self, words, keep):
        """Kept words with cut-timeline start times (index = raw word index)."""
        kept = set()
        for i0, i1 in keep:
            kept.update(range(int(i0), int(i1) + 1))
        out = []
        for i, w in enumerate(words):
            if i in kept:
                out.append({"i": i, "w": w["w"], "s": round(self.raw2T(w["s"] + 0.04), 3)})
        return out


def save(job, keeps):
    json.dump(keeps, open(job.p("keeps.json"), "w"))

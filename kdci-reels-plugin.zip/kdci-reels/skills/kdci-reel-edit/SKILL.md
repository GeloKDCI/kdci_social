---
name: kdci-reel-edit
description: Edit a KDCI 9:16 talking-head reel from a folder of raw footage, B-roll, images, music, SFX and end card — retakes and dead air cut, zoom cuts, glass graphics behind the head, chat/stat cards, karaoke captions, voice clean-up, end card, -14 LUFS export. Use when someone asks to edit or make a KDCI reel from their assets.
---

# KDCI reel edit

You are the editor. Bundled scripts do the heavy lifting (transcription, cutting, voice, base video, person cut-out, HyperFrames render, mix); **you** write the edit plan (retakes, shots, B-roll choices, graphics, keywords) and review the result. No API key is needed — the planning is your own work in this conversation.

Scripts live next to this file: `SCRIPTS=<this skill's base directory>/scripts`, run as `python3 "$SCRIPTS/reel.py" <command>`. Every command prints what it did; read the output.

Brand specs are built in (do not ask the user): 1080x1920 30 fps, captions Inter SemiBold 58 px lower third with red #E61739 keyword pills, overlay text Plus Jakarta Sans ExtraBold, glass panels behind the talent's head, music ~-23 dB under the voice, camera-shutter pops, end card with its own audio, -14 LUFS / -1.5 dBTP, H.264.

## Expected folder

```
<root>/Raw Main Footage/   the talking-head clip (one)
<root>/B-Rolls/            stock clips (+ PNG logos/icons)
<root>/BG Music/           one track
<root>/Sound FX/           camera shutter (pop) and laptop typing
<root>/End Card Logo/      *_ALPHA.mov end card
<root>/Fonts/              PlusJakartaSans-ExtraBold.ttf (optional, bundled anyway)
<root>/<any other folder>  extra images (photos become round avatars, transparent PNGs become icons)
<root>/From Claude/        deliverables go here
```
Folders named `From Claude` / `Exported Final Video` are ignored. If the layout differs, files are still classified by name and type; fix any category with `ingest --set "<file name>=<cat>"` (cats: raw, broll, images, music, endcard, sfx_pop, sfx_typing, font) or leave files out with `--skip <text>`.

## Workflow (use a task list)

1. **Get the files into the workspace.** If the folder is on the user's computer (Cowork, linked folder), stage everything except the `From Claude` and `Exported Final Video` folders with `device_stage_files` (≤50 files per call; put the big raw clip and end card in their own call). They land under `/mnt/user-data/uploads/<folder-name>/`, keeping sub-folders. Work in the cloud container, not the device shell — renders take far longer than its time limit. If you are running directly on the machine that holds the folder, use the folder path as is.
2. **Setup:** `python3 "$SCRIPTS/reel.py" setup` (installs Python packages, downloads the speech and matting models from GitHub, checks ffmpeg/npx; ~1–2 min the first time).
3. **Ingest:** `python3 "$SCRIPTS/reel.py" ingest "<folder>"` → prints `JOB <id>` and every asset with a thumbnail path. **Read every B-roll and image thumbnail** (they are contact sheets) so you know what each clip shows. Check the categories (exactly one raw clip; a sound-effect video sitting in B-Rolls is detected as SFX).
4. **Transcribe:** `python3 "$SCRIPTS/reel.py" transcribe --job <id>` → indexed transcript `[i]word`, with sentence end times and long pauses marked.
5. **Plan:** `python3 "$SCRIPTS/reel.py" guide` prints the house-style guide, the plan JSON schema and the path of a full example plan from a previous KDCI reel — read both. Then write `plan.json` in the job folder:
   - `keep`: word ranges to keep. **Drop flubbed retakes** — when a line is said several times, keep the last clean take; drop swears, false starts and asides.
   - `shots`: alternating zoom cuts every sentence/clause, punch-ins on key lines, B-roll matched to the words (use every clip that fits; each at most twice, second time with another `src_start` or `flip`).
   - `graphics`: 8–14 short, punchy cards synced to word indices (hook, chat UI, stat, chips, reframe, KDCI header, CTA with the URL). Never invent stats or sources.
   - `keywords`: 8–15 word indices for the red caption pill.
6. **Preview:** `python3 "$SCRIPTS/reel.py" preview --job <id> --plan <job folder>/plan.json` (2–5 min). It cuts dead air, cleans the voice, renders the base video and the graphics, then prints the edit length, the B-roll and graphic timings and **snapshot sheets** (one frame near the end of each graphic). **Read every sheet** and fix: text under or behind the head, overflowing rows, unreadable contrast, graphics that cover the wrong line, B-roll that doesn't match. Edit plan.json and run preview again (it only re-renders what changed). Two or three rounds is normal.
7. **Check with the user** if they are around: send the snapshot sheets (copy them to `/mnt/user-data/outputs/` and `SendUserFile`) with a 2–3 line summary of the edit and ask for changes. If they are away, continue.
8. **Render:** `python3 "$SCRIPTS/reel.py" render --job <id> --out /mnt/user-data/outputs` starts the final render in the background (person cut-out, HyperFrames render, mix, end card). It takes ~30–45 min in a 2-core sandbox. Poll with `python3 "$SCRIPTS/reel.py" status --job <id>` every ~8–9 minutes (`sleep 500` between polls). On `ERROR`, read `<job>/work/render.log`, fix, and run render again (finished stages are reused).
9. **Verify:** make a contact sheet of the output (`ffmpeg -i OUT -vf fps=1/1.6,scale=180:-1,tile=13x4 -frames:v 1 sheet.jpg`) and look at it; status shows duration and LUFS (≈ -14).
10. **Deliver:** the file is `KDCI Reel - <Title>_vN.mp4` in the out folder (never overwrites). `SendUserFile` it, then copy it into the user's `From Claude` folder:
    - `device_commit_files` takes ≤30 MB per file: `split -b 25M -d FILE parts/x.part`, commit each part to `From Claude/_tmp_parts/`. If a part is rejected with "HTTP 400 fetching session file", `SendUserFile` that part and commit it by `fileUuid`.
    - On the device: `md5sum` each part and compare with the cloud copy (re-send any part that differs, with `force: true`), `cat` them into the final name, `sync`, then check `md5sum` and `ffprobe` of the result. Sizes can read short for a few seconds after writing — re-check after `sync; sleep 5`.
    - Remove `_tmp_parts` (ask for delete permission once, naming those temp files). Never leave scratch files in the user's folder.
11. If a Claude Project is attached, save a short edit-notes doc there (title, version, length, assets used, deviations).

## Good to know

- Raw clips already cleaned by a voice-isolation tool (silent noise floor) are detected and only get EQ/compression; noisy ones also get FFT denoising.
- Disk: the HyperFrames render needs ~15–20 GB of temporary space; it is deleted afterwards. If the sandbox disk fills up, delete old job folders under `~/kdci-reel-jobs/jobs/`.
- Never kill processes with a `pkill -f` pattern that also matches your own shell command.
- The user's own folder is read-only for you except `From Claude/`; never modify or delete their source files.
